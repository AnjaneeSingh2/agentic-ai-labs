#!/usr/bin/env python3
"""
web_func.py
=======
OCI Function version of app.py. Same oci.generative_ai_agent_runtime calls
(create_session + chat), triggered by an HTTP request via API Gateway
instead of a Flask route.

POST body:  {"message": "...", "session_id": "<optional>"}
Response:   {"reply": "...", "citations": [...], "session_id": "..."}

Configuration (set as function config vars, see fn config below):
    AGENT_ENDPOINT_ID                 (required)
    OCI_GENAI_AGENT_SERVICE_ENDPOINT  (optional)

Auth: uses the Resource Principal signer (no ~/.oci/config needed). The
function's Dynamic Group must have a policy granting
"use generative-ai-agent-runtime-family" in the agent's compartment.

NOTE on sessions: Function containers are ephemeral and can be recycled
between invocations, so we don't rely on in-process state the way app.py
did. Instead, session_id is created on first message and handed back to
the caller, who must send it on every following message. This keeps the
same OCI-side multi-turn conversation working regardless of which
container instance handles a given request.
"""

import io
import json
import os

import oci
from fdk import response
from oci.generative_ai_agent_runtime import GenerativeAiAgentRuntimeClient
from oci.generative_ai_agent_runtime.models import ChatDetails, CreateSessionDetails

AGENT_ENDPOINT_ID = os.getenv("AGENT_ENDPOINT_ID", "")
SERVICE_ENDPOINT = os.getenv("OCI_GENAI_AGENT_SERVICE_ENDPOINT")

# Reused across warm invocations of the same container (best-effort cache,
# not relied on for correctness -- session_id round-trips through the client).
_client = None


def _get_client() -> GenerativeAiAgentRuntimeClient:
    global _client
    if _client is None:
        signer = oci.auth.signers.get_resource_principals_signer()
        kwargs = {"retry_strategy": oci.retry.DEFAULT_RETRY_STRATEGY}
        if SERVICE_ENDPOINT:
            kwargs["service_endpoint"] = SERVICE_ENDPOINT
        _client = GenerativeAiAgentRuntimeClient(config={}, signer=signer, **kwargs)
    return _client


def _create_session(client: GenerativeAiAgentRuntimeClient) -> str:
    try:
        details = CreateSessionDetails(
            display_name="web-session",
            idle_timeout_in_seconds=3600,
        )
    except TypeError:
        details = CreateSessionDetails(display_name="web-session")
    session = client.create_session(
        create_session_details=details,
        agent_endpoint_id=AGENT_ENDPOINT_ID,
    )
    return session.data.id


def _extract_text_and_citations(message_content):
    text = getattr(message_content, "text", None)
    if text is None:
        text = str(message_content)
    citations = getattr(message_content, "citations", None) or []
    formatted = []
    for c in citations:
        source_title = getattr(c, "source_title", None) or getattr(c, "title", None) or "unknown"
        source_location = getattr(c, "source_location", None)
        url = getattr(source_location, "url", None) if source_location else None
        formatted.append({"title": source_title, "url": url})
    return text, formatted


def _json_response(ctx, status_code, payload):
    return response.Response(
        ctx,
        status_code=status_code,
        response_data=json.dumps(payload),
        headers={"Content-Type": "application/json"},
    )


def handler(ctx, data: io.BytesIO = None):
    if not AGENT_ENDPOINT_ID:
        return _json_response(ctx, 500, {"error": "AGENT_ENDPOINT_ID is not set on the function."})

    try:
        raw = data.getvalue() if data else b""
        body = json.loads(raw) if raw else {}
    except Exception:
        body = {}

    question = (body.get("message") or "").strip()
    session_id = body.get("session_id")

    if not question:
        return _json_response(ctx, 400, {"error": "Empty message."})

    try:
        client = _get_client()

        if not session_id:
            session_id = _create_session(client)

        chat_response = client.chat(
            agent_endpoint_id=AGENT_ENDPOINT_ID,
            chat_details=ChatDetails(
                user_message=question,
                session_id=session_id,
                should_stream=False,
            ),
        )
        text, citations = _extract_text_and_citations(chat_response.data.message.content)
        return _json_response(ctx, 200, {"reply": text, "citations": citations, "session_id": session_id})

    except oci.exceptions.ServiceError as e:
        # Session likely died (idle timeout / invalid) -- tell the client to
        # drop it so the *next* request creates a fresh one, since we can't
        # retry transparently without knowing whether the message was applied.
        return _json_response(
            ctx,
            502,
            {
                "error": f"OCI service error ({e.status} {e.code}): {e.message}",
                "session_expired": e.status in (400, 404),
            },
        )
    except oci.exceptions.RequestException as e:
        return _json_response(ctx, 502, {"error": f"Network/request error: {e}"})