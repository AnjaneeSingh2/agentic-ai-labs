import csv, io, json, os
import oci
from fdk import response

BUCKET_NAME = "oci-change-tracker"
NAMESPACE = "froqh6dvllfq"
CSV_PATH = "/tmp/resources.csv"
NARRATIVE_PATH = "/tmp/instance_narratives.txt"
LIGHT_CSV_PATH = "/tmp/lightweight_inventory.csv"
LIGHT_NARRATIVE_PATH = "/tmp/lightweight_narratives.txt"

LIGHT_TYPES = ["vcn", "subnet", "volume", "bootvolume", "loadbalancer", "bucket", "database"]

FIELDS = [
    "display_name", "id", "compartment_id", "compartment_name", "lifecycle_state", "shape",
    "ocpus", "memory_in_gbs", "availability_domain", "fault_domain", "region", "image_id",
    "time_created", "freeform_tags", "defined_tags", "subnets", "private_ips", "public_ips",
    "nsg_ids", "boot_volume_id", "boot_volume_size_gbs", "boot_volume_vpus_per_gb",
    "boot_volume_kms_key_id", "boot_volume_backup_policy", "attached_volumes",
    "total_storage_gbs", "cpu_util_pct", "mem_util_pct", "net_bytes_in", "net_bytes_out",
]

LIGHT_FIELDS = [
    "resource_type", "display_name", "id", "compartment_id", "compartment_name",
    "lifecycle_state", "availability_domain", "time_created", "freeform_tags", "defined_tags",
]


def get_compartment_map(identity, tenancy_id):
    comps = oci.pagination.list_call_get_all_results(
        identity.list_compartments, tenancy_id, compartment_id_in_subtree=True, lifecycle_state="ACTIVE"
    ).data
    cmap = {c.id: c.name for c in comps}
    cmap[tenancy_id] = identity.get_tenancy(tenancy_id).data.name + " (root)"
    return cmap


def list_all_resources(search):
    q = oci.resource_search.models.StructuredSearchDetails(
        query="query instance resources", type="Structured", matching_context_type="NONE"
    )
    return oci.pagination.list_call_get_all_results(search.search_resources, q).data


def search_by_type(search_client, resource_types: list):
    q = oci.resource_search.models.StructuredSearchDetails(
        query=f"query {', '.join(resource_types)} resources", type="Structured", matching_context_type="NONE"
    )
    return oci.pagination.list_call_get_all_results(search_client.search_resources, q).data


def get_utilization(mon, comp_id, inst_id):
    out = {}
    for key, name in [("cpu_util_pct", "CpuUtilization"), ("mem_util_pct", "MemoryUtilization"),
                       ("net_bytes_in", "NetworksBytesIn"), ("net_bytes_out", "NetworksBytesOut")]:
        out[key] = ""
        try:
            q = f'{name}[1m]{{resourceId = "{inst_id}"}}.mean()'
            d = mon.summarize_metrics_data(comp_id, oci.monitoring.models.SummarizeMetricsDataDetails(
                namespace="oci_computeagent", query=q)).data
            if d and d[0].aggregated_datapoints:
                out[key] = d[0].aggregated_datapoints[-1].value
        except oci.exceptions.ServiceError:
            pass
    return out


def get_storage(inst, compute, bs):
    s = {"boot_volume_id": "", "boot_volume_size_gbs": "", "boot_volume_vpus_per_gb": "",
         "boot_volume_kms_key_id": "", "boot_volume_backup_policy": "", "attached_volumes": "",
         "total_storage_gbs": 0}
    try:
        boots = oci.pagination.list_call_get_all_results(
            compute.list_boot_volume_attachments, availability_domain=inst.availability_domain,
            compartment_id=inst.compartment_id, instance_id=inst.id).data
        if not boots:
            print(f"[storage] {inst.display_name}: no boot volume attachment found")
        else:
            bv = bs.get_boot_volume(boots[0].boot_volume_id).data
            s.update(boot_volume_id=bv.id, boot_volume_size_gbs=bv.size_in_gbs,
                      boot_volume_vpus_per_gb=bv.vpus_per_gb, boot_volume_kms_key_id=bv.kms_key_id or "")
            s["total_storage_gbs"] += bv.size_in_gbs or 0
            try:
                a = bs.get_volume_backup_policy_asset_assignment(bv.id).data
                s["boot_volume_backup_policy"] = a[0].policy_id if a else "None"
            except oci.exceptions.ServiceError as e:
                print(f"[storage] {inst.display_name}: backup policy lookup failed - {e.status} {e.code} {e.message}")
    except oci.exceptions.ServiceError as e:
        print(f"[storage] {inst.display_name}: boot volume lookup failed - {e.status} {e.code} {e.message}")
    try:
        vols = oci.pagination.list_call_get_all_results(
            compute.list_volume_attachments, compartment_id=inst.compartment_id, instance_id=inst.id).data
        parts = []
        for va in vols:
            try:
                v = bs.get_volume(va.volume_id).data
                parts.append(f"{v.display_name}:{v.id}:{v.size_in_gbs}GB:{v.vpus_per_gb}VPU")
                s["total_storage_gbs"] += v.size_in_gbs or 0
            except oci.exceptions.ServiceError as e:
                print(f"[storage] {inst.display_name}: attached volume lookup failed - {e.status} {e.code} {e.message}")
                parts.append(f"{va.display_name}:{va.volume_id}")
        s["attached_volumes"] = ";".join(parts)
    except oci.exceptions.ServiceError as e:
        print(f"[storage] {inst.display_name}: volume attachment list failed - {e.status} {e.code} {e.message}")
    return s


def enrich(summary, compute, vnic_c, bs, mon, comp_map):
    inst = compute.get_instance(summary.identifier).data
    row = {
        "display_name": inst.display_name, "id": inst.id, "compartment_id": inst.compartment_id,
        "compartment_name": comp_map.get(inst.compartment_id, ""), "lifecycle_state": inst.lifecycle_state,
        "shape": inst.shape, "ocpus": getattr(inst.shape_config, "ocpus", ""),
        "memory_in_gbs": getattr(inst.shape_config, "memory_in_gbs", ""),
        "availability_domain": inst.availability_domain, "fault_domain": inst.fault_domain,
        "region": inst.region, "image_id": inst.image_id, "time_created": inst.time_created,
        "freeform_tags": inst.freeform_tags, "defined_tags": inst.defined_tags,
        "subnets": "", "private_ips": "", "public_ips": "", "nsg_ids": "",
    }
    try:
        vnics = oci.pagination.list_call_get_all_results(
            compute.list_vnic_attachments, compartment_id=inst.compartment_id, instance_id=inst.id).data
        subnets, priv, pub, nsgs = [], [], [], []
        for va in vnics:
            if not va.vnic_id:
                continue
            v = vnic_c.get_vnic(va.vnic_id).data
            subnets.append(v.subnet_id or ""); priv.append(v.private_ip or "")
            pub.append(v.public_ip or ""); nsgs.extend(v.nsg_ids or [])
        row.update(subnets=";".join(subnets), private_ips=";".join(priv),
                   public_ips=";".join(pub), nsg_ids=";".join(nsgs))
    except oci.exceptions.ServiceError:
        pass
    row.update(get_storage(inst, compute, bs))
    row.update(get_utilization(mon, inst.compartment_id, inst.id))
    return row


def to_light_row(r, comp_map):
    return {
        "resource_type": r.resource_type, "display_name": r.display_name, "id": r.identifier,
        "compartment_id": r.compartment_id, "compartment_name": comp_map.get(r.compartment_id, ""),
        "lifecycle_state": r.lifecycle_state, "availability_domain": getattr(r, "availability_domain", "") or "",
        "time_created": r.time_created, "freeform_tags": r.freeform_tags, "defined_tags": r.defined_tags,
    }


def generate_narrative(resources: list) -> str:
    out = []
    for r in resources:
        n, kms = r["display_name"], r.get("boot_volume_kms_key_id")
        enc = f"customer-managed encryption with KMS key {kms}" if kms else "Oracle-managed default encryption"

        facts = [
            f"{n} is a compute instance in the {r['compartment_name']} compartment, currently "
            f"{r['lifecycle_state']}, running on shape {r['shape']} with {r['ocpus']} OCPUs and "
            f"{r['memory_in_gbs']} GB memory in {r['availability_domain']}.",

            f"{n}'s network: Private IP(s) {r.get('private_ips') or 'none'}, "
            f"Public IP(s) {r.get('public_ips') or 'none'}.",

            # Boot volume facts get their own dedicated sentences so a query about
            # boot volumes matches tightly, even if the chunker splits mid-paragraph.
            f"{n}'s boot volume is {r.get('boot_volume_size_gbs') or 'unknown'} GB in size, "
            f"with a performance tier of {r.get('boot_volume_vpus_per_gb') or 'unknown'} VPUs/GB.",

            f"{n}'s boot volume backup policy is '{r.get('boot_volume_backup_policy') or 'None'}', "
            f"and it uses {enc}.",

            f"{n}'s boot volume OCID is {r.get('boot_volume_id') or 'unknown'}.",

            f"{n} has the following block volumes attached (in addition to its boot volume): {r['attached_volumes']}." if r.get("attached_volumes")
            else f"{n} has no block volumes attached; it only has its boot volume.",

            f"{n}'s total storage across boot and attached volumes is {r.get('total_storage_gbs', 0)} GB.",

            f"{n}'s recent utilization: CPU at {r.get('cpu_util_pct') or 'unknown'}%, "
            f"memory at {r.get('mem_util_pct') or 'unknown'}%.",
        ]
        out.append("\n".join(facts))
    return "\n\n".join(out)


def generate_light_narrative(rows: list) -> str:
    out = []
    for r in rows:
        out.append(
            f"{r['display_name']} is a {r['resource_type']} resource in the {r['compartment_name']} "
            f"compartment, currently in {r['lifecycle_state']} state, created on {r['time_created']}."
        )
    return "\n\n".join(out)


def print_and_save_resources(resources: list, path: str = "resources.csv"):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for r in resources:
            print(f"{r['display_name']:<30} {r['shape']:<25} {r['lifecycle_state']:<12} "
                  f"CPU%={r['cpu_util_pct']} Mem%={r['mem_util_pct']}")
            w.writerow(r)
    print(f"Saved {len(resources)} instance(s) to {path}")


def save_light_csv(rows: list, path: str = LIGHT_CSV_PATH):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=LIGHT_FIELDS)
        w.writeheader()
        for r in rows:
            print(f"{r['resource_type']:<15} {r['display_name']:<30} {r['lifecycle_state']:<12} {r['compartment_name']}")
            w.writerow(r)
    print(f"Saved {len(rows)} resource(s) to {path}")


def upload(os_client, local_path, object_name):
    with open(local_path, "rb") as f:
        os_client.put_object(NAMESPACE, BUCKET_NAME, object_name, f)
    print(f"Uploaded {object_name} to '{BUCKET_NAME}'.")


def trigger_ingestion(kwargs, tenancy_id):
    data_source_id = os.environ.get("DATA_SOURCE_ID")
    if not data_source_id:
        print("DATA_SOURCE_ID not set; skipped re-ingestion.")
        return False
    try:
        oci.generative_ai_agent.GenerativeAiAgentClient(**kwargs).create_data_ingestion_job(
            oci.generative_ai_agent.models.CreateDataIngestionJobDetails(
                compartment_id=os.environ.get("AGENT_COMPARTMENT_ID", tenancy_id),
                data_source_id=data_source_id, display_name="auto-ingest-after-report",
            ))
        print("Triggered knowledge base re-ingestion.")
        return True
    except oci.exceptions.ServiceError as e:
        print(f"Failed to trigger re-ingestion: {e}")
        return False


def handler(ctx, data: io.BytesIO = None):
    signer = oci.auth.signers.get_resource_principals_signer()
    kwargs = dict(config={}, signer=signer)
    search, compute, vnic_c, bs, mon, os_client, identity = (
        oci.resource_search.ResourceSearchClient(**kwargs), oci.core.ComputeClient(**kwargs),
        oci.core.VirtualNetworkClient(**kwargs), oci.core.BlockstorageClient(**kwargs),
        oci.monitoring.MonitoringClient(**kwargs), oci.object_storage.ObjectStorageClient(**kwargs),
        oci.identity.IdentityClient(**kwargs),
    )

    comp_map = get_compartment_map(identity, signer.tenancy_id)

    # Detailed compute instance report (storage, networking, utilization)
    found = list_all_resources(search)
    resources = [enrich(r, compute, vnic_c, bs, mon, comp_map) for r in found]
    print_and_save_resources(resources, CSV_PATH)
    upload(os_client, CSV_PATH, "resources.csv")

    with open(NARRATIVE_PATH, "w", encoding="utf-8") as f:
        f.write(generate_narrative(resources))
    upload(os_client, NARRATIVE_PATH, "instance_narratives.txt")

    # Lightweight multi-type inventory (VCNs, subnets, volumes, LBs, buckets, databases, etc.)
    light_found = search_by_type(search, LIGHT_TYPES)
    light_rows = [to_light_row(r, comp_map) for r in light_found]
    save_light_csv(light_rows, LIGHT_CSV_PATH)
    upload(os_client, LIGHT_CSV_PATH, "lightweight_inventory.csv")

    with open(LIGHT_NARRATIVE_PATH, "w", encoding="utf-8") as f:
        f.write(generate_light_narrative(light_rows))
    upload(os_client, LIGHT_NARRATIVE_PATH, "lightweight_narratives.txt")

    ingestion_triggered = trigger_ingestion(kwargs, signer.tenancy_id)

    return response.Response(
        ctx,
        response_data=json.dumps({
            "instances_found": len(resources), "other_resources_found": len(light_rows),
            "compartments_found": len(comp_map), "bucket": BUCKET_NAME,
            "ingestion_triggered": ingestion_triggered,
        }),
        headers={"Content-Type": "application/json"},
    )
