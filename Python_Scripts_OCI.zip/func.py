import io
import json
import logging
from datetime import datetime, timedelta, timezone

import oci

logging.getLogger().setLevel(logging.INFO)

# ---- Configure these for your setup ----
NAMESPACE = "idsna7fjvtua"   # find via: oci os ns get
BUCKET_NAME = "agent-change-log"
PREFIX = "snapshots/"                          # folder/prefix where snapshot.py writes files
DAYS_TO_LOOK_BACK = 30


def handler(ctx, data: io.BytesIO = None):
    """
    Reads every snapshot object written in the last DAYS_TO_LOOK_BACK days
    from Object Storage, parses each one, and combines them.
    """
    try:
        signer = oci.auth.signers.get_resource_principals_signer()
        client = oci.object_storage.ObjectStorageClient(config={}, signer=signer)

        cutoff = datetime.now(timezone.utc) - timedelta(days=DAYS_TO_LOOK_BACK)

        matching_objects = list_recent_objects(client, cutoff)
        logging.info(f"Found {len(matching_objects)} snapshot(s) within the last {DAYS_TO_LOOK_BACK} days")

        combined_data = []
        for obj_name in matching_objects:
            snapshot = read_snapshot(client, obj_name)
            if snapshot is not None:
                combined_data.append({"source_object": obj_name, "data": snapshot})

        result = process_combined_snapshots(combined_data)

        return {
            "status": "success",
            "snapshots_read": len(combined_data),
            "result": result,
        }

    except oci.exceptions.ServiceError as e:
        logging.error(f"Object Storage error: {e}")
        return {"status": "error", "message": str(e)}
    except Exception as e:
        logging.error(f"Unexpected error: {e}")
        return {"status": "error", "message": str(e)}


def list_recent_objects(client, cutoff):
    """
    Lists all objects under PREFIX whose time_created is after `cutoff`.
    Paginates automatically since a bucket can hold more objects than one page returns.
    """
    matching = []
    next_start = None

    while True:
        response = client.list_objects(
            namespace_name=NAMESPACE,
            bucket_name=BUCKET_NAME,
            prefix=PREFIX,
            fields="name,timeCreated",  # ask API to include timeCreated, it's not returned by default
            start=next_start,
        )

        for obj in response.data.objects:
            if obj.time_created and obj.time_created >= cutoff:
                matching.append(obj.name)

        next_start = response.data.next_start_with
        if not next_start:
            break

    return matching


def read_snapshot(client, object_name):
    """Fetches and parses a single snapshot object. Adjust parsing to match your file format."""
    try:
        response = client.get_object(
            namespace_name=NAMESPACE,
            bucket_name=BUCKET_NAME,
            object_name=object_name,
        )
        content = response.data.content.decode("utf-8")
        return json.loads(content)  # change to csv/plain parsing if snapshot.py doesn't write JSON
    except Exception as e:
        logging.warning(f"Skipping {object_name}, failed to read/parse: {e}")
        return None


def process_combined_snapshots(combined_data):
    """
    Replace this with your actual analysis/aggregation logic.
    'combined_data' is a list of {"source_object": ..., "data": ...} dicts,
    one per snapshot found in the last 30 days.
    """
    return {
        "total_snapshots": len(combined_data),
        "objects_included": [item["source_object"] for item in combined_data],
    }