#!/usr/bin/env python3
"""
Query an OCI Generative AI Agent (with its attached Knowledge Base) from your
Linux machine.

Setup
-----
1. Install the SDK:
       pip install oci
2. Make sure ~/.oci/config is set up with a working profile
   (run `oci setup config` if you haven't, or point OCI_CONFIG_PROFILE below
   at an existing profile). The user in that config needs a policy allowing
   USE of generative-ai-agent-runtime resources in the agent's compartment.
3. Set the agent endpoint OCID as an environment variable (recommended,
   rather than hardcoding it in the script):

       export AGENT_ENDPOINT_ID="ocid1.genaiagentendpoint.oc1.iad.amaaaaaah2vcsdqa3x6hrkuj4lzla2piqeps4elhm36ryi7xxvcpr5ssfhxq"
       export AGENT="ocid1.genaiagent.oc1.iad.amaaaaaah2vcsdqacj4ggtb3avah7huglqi2uwpzij6goyfhs3h5mkykqirq"

   Optionally set SERVICE_ENDPOINT if your tenancy/region needs an explicit one.

Usage
-----
    python3 query_oci_agent.py "What does the onboarding policy say about laptops?"
    # or run interactively:
    python3 query_oci_agent.py

    # to also print any citations returned by the knowledge base:
    python3 query_oci_agent.py --show-citations "What does the onboarding policy say?"
"""

import os
import sys
import oci
from oci.generative_ai_agent_runtime import GenerativeAiAgentRuntimeClient
from oci.generative_ai_agent_runtime.models import ChatDetails, CreateSessionDetails

# ---- Configuration -------------------------------------------------------
CONFIG_PROFILE = os.getenv("OCI_CONFIG_PROFILE", "DEFAULT")
AGENT_ENDPOINT_ID = os.getenv("AGENT_ENDPOINT_ID", "<AGENT_ENDPOINT_OCID>")
SERVICE_ENDPOINT = os.getenv("OCI_GENAI_AGENT_SERVICE_ENDPOINT")  # optional
# ---------------------------------------------------------------------------


def get_client() -> GenerativeAiAgentRuntimeClient:
    try:
        config = oci.config.from_file(profile_name=CONFIG_PROFILE)
    except oci.exceptions.ConfigFileNotFound as e:
        sys.exit(f"OCI config not found or invalid (profile '{CONFIG_PROFILE}'): {e}")

    kwargs = {"retry_strategy": oci.retry.DEFAULT_RETRY_STRATEGY}
    if SERVICE_ENDPOINT:
        kwargs["service_endpoint"] = SERVICE_ENDPOINT
    return GenerativeAiAgentRuntimeClient(config, **kwargs)


def create_session(client: GenerativeAiAgentRuntimeClient) -> str:
    # idle_timeout_in_seconds was added in a later SDK release than some
    # environments have installed. Try with it first, and if the installed
    # SDK's CreateSessionDetails doesn't recognize it, fall back without it
    # rather than requiring the user to pin a specific oci version.
    try:
        session_details = CreateSessionDetails(
            display_name="cli-session",
            idle_timeout_in_seconds=3600,
        )
    except TypeError:
        session_details = CreateSessionDetails(display_name="cli-session")

    try:
        session = client.create_session(
            create_session_details=session_details,
            agent_endpoint_id=AGENT_ENDPOINT_ID,
        )
        return session.data.id
    except oci.exceptions.ServiceError as e:
        sys.exit(
            f"Failed to create session (status {e.status}, code {e.code}): "
            f"{e.message}\nCheck that AGENT_ENDPOINT_ID is correct and your "
            f"IAM policy grants USE on generative-ai-agent-runtime resources."
        )


def _extract_text_and_citations(message_content):
    """
    Defensively pull text (and citations, if present) out of the chat
    response content object. The SDK's content shape can vary by version /
    whether the agent attached retrieval results, so don't assume a single
    fixed structure.
    """
    text = getattr(message_content, "text", None)
    if text is None:
        # Fall back to string conversion if the shape is unexpected
        text = str(message_content)

    citations = getattr(message_content, "citations", None) or []
    return text, citations


def ask(client: GenerativeAiAgentRuntimeClient, session_id: str, question: str):
    """
    Returns (answer_text, citations). Raises no exception on API errors;
    instead returns an error message as the text and an empty citation list,
    so an interactive loop can keep going after a single failed turn.
    """
    try:
        response = client.chat(
            agent_endpoint_id=AGENT_ENDPOINT_ID,
            chat_details=ChatDetails(
                user_message=question,
                session_id=session_id,
                should_stream=False,
            ),
        )
    except oci.exceptions.ServiceError as e:
        return (
            f"[error] Request failed (status {e.status}, code {e.code}): {e.message}",
            [],
        )
    except oci.exceptions.RequestException as e:
        return (f"[error] Network/request error: {e}", [])

    try:
        content = response.data.message.content
    except AttributeError:
        return ("[error] Unexpected response shape from the agent API.", [])

    return _extract_text_and_citations(content)


def format_citations(citations) -> str:
    if not citations:
        return ""
    lines = ["\nSources:"]
    for i, c in enumerate(citations, 1):
        # Field names vary by SDK version; grab what's available defensively.
        source_title = getattr(c, "source_title", None) or getattr(c, "title", None) or "unknown"
        source_location = getattr(c, "source_location", None)
        url = getattr(source_location, "url", None) if source_location else None
        line = f"  [{i}] {source_title}"
        if url:
            line += f" - {url}"
        lines.append(line)
    return "\n".join(lines)


def main():
    show_citations = "--show-citations" in sys.argv
    args = [a for a in sys.argv[1:] if a != "--show-citations"]

    if AGENT_ENDPOINT_ID.startswith("<"):
        sys.exit(
            "Set AGENT_ENDPOINT_ID (env var, e.g. `export AGENT_ENDPOINT_ID=ocid1....`) "
            "before running."
        )

    client = get_client()
    session_id = create_session(client)

    def respond(question: str):
        text, citations = ask(client, session_id, question)
        print(text)
        if show_citations:
            formatted = format_citations(citations)
            if formatted:
                print(formatted)

    if args:
        respond(" ".join(args))
        return

    print("Connected. Type a question (Ctrl+C or empty line to quit).")
    while True:
        try:
            question = input("\n> ").strip()
        except (KeyboardInterrupt, EOFError):
            print()
            break
        if not question:
            break
        respond(question)


if __name__ == "__main__":
    main()