#!/usr/bin/env python3
"""
historical_deletions.py
========================
One-time (or periodic) backfill of resources that were DELETED before your
snapshot.py tracking started. Pulls two sources:

  1. Compartments with lifecycle_state == DELETED (via Identity API,
     unfiltered by state) -- confirmed accurate, same data you saw with
     `oci iam compartment list` earlier.
  2. OCI Audit Service events for actions that look like deletions, across
     all compartments, for a lookback window (default 365 days -- OCI's
     default audit retention). Best-effort: event/action naming varies by
     service, so this uses a substring match on common patterns. Treat
     this list as a starting point, not a guaranteed-complete record.

Writes historical-deletions.json to the same Object Storage bucket used by
snapshot.py, so it can be ingested into the agent's knowledge base as its
own document, separate from latest.json.

Usage:
  python3 historical_deletions.py \
      --compartment-id ocid1.tenancy.oc1..xxxx \
      --bucket agent-change-log \
      --namespace idsna7fjvtua \
      [--days 365] \
      [--profile DEFAULT] \
      [--region us-ashburn-1]
"""

from __future__ import annotations

import argparse
import json
import logging
from datetime import datetime, timedelta, timezone

import oci

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
log = logging.getLogger("historical_deletions")

DELETE_KEYWORDS = ("delete", "terminate", "remove")


def get_clients(profile, region):
    config = oci.config.from_file(profile_name=profile)
    if region:
        config["region"] = region
    return {
        "identity": oci.identity.IdentityClient(config),
        "audit": oci.audit.AuditClient(config),
        "object_storage": oci.object_storage.ObjectStorageClient(config),
    }


def fetch_deleted_compartments(identity_client, root_compartment_id):
    """List ALL compartments (no lifecycle_state filter) and keep the deleted ones."""
    log.info("Fetching all compartments (any lifecycle state) to find deletions...")
    response = oci.pagination.list_call_get_all_results(
        identity_client.list_compartments,
        root_compartment_id,
        compartment_id_in_subtree=True,
    )
    deleted = []
    for c in response.data:
        if c.lifecycle_state == "DELETED":
            deleted.append({
                "resource_type": "compartment",
                "display_name": c.name,
                "id": c.id,
                "lifecycle_state": c.lifecycle_state,
                "description": c.description,
                "time_created": str(c.time_created),
            })
    log.info("Found %d deleted compartment(s)", len(deleted))
    return deleted


def fetch_audit_deletions(audit_client, identity_client, root_compartment_id, days):
    """
    Best-effort scan of OCI Audit events for delete-like actions.

    Important: Audit's list_events does NOT traverse sub-compartments even
    when given the tenancy/root OCID -- it only returns events for the
    exact compartment passed in. So we enumerate every compartment
    (root + active sub-compartments) and query each one individually.
    """
    log.info("Fetching audit events for the last %d day(s), across all compartments...", days)
    end_time = datetime.now(timezone.utc)
    start_time = end_time - timedelta(days=days)

    # Enumerate all compartments to query individually (Audit doesn't support subtree).
    compartment_ids = [root_compartment_id]
    try:
        comp_response = oci.pagination.list_call_get_all_results(
            identity_client.list_compartments,
            root_compartment_id,
            compartment_id_in_subtree=True,
            lifecycle_state="ACTIVE",
        )
        compartment_ids.extend(c.id for c in comp_response.data)
    except oci.exceptions.ServiceError as ex:
        log.warning("Could not enumerate sub-compartments for audit scan (%s: %s) -- "
                     "only scanning the root/tenancy compartment.", ex.status, ex.message)

    events = []
    for cid in compartment_ids:
        try:
            response = oci.pagination.list_call_get_all_results(
                audit_client.list_events,
                compartment_id=cid,
                start_time=start_time,
                end_time=end_time,
            )
            for e in response.data:
                event_name = (getattr(e, "event_name", "") or "").lower()
                if any(kw in event_name for kw in DELETE_KEYWORDS):
                    data = getattr(e, "data", None)
                    events.append({
                        "resource_type": getattr(data, "resource_name", None) or "unknown",
                        "event_name": getattr(e, "event_name", None),
                        "event_time": str(getattr(e, "event_time", None)),
                        "compartment_id": cid,
                        "identity": {
                            "principal_name": getattr(getattr(data, "identity", None),
                                                       "principal_name", None),
                        } if data else None,
                    })
        except oci.exceptions.ServiceError as ex:
            log.warning("Audit event fetch failed for compartment %s (%s: %s) -- skipping it.",
                         cid, ex.status, ex.message)
            continue

    log.info("Found %d delete-like audit event(s) across %d compartment(s)",
              len(events), len(compartment_ids))
    return events


def main():
    parser = argparse.ArgumentParser(description="Backfill historical deletion data")
    parser.add_argument("--compartment-id", required=True)
    parser.add_argument("--bucket", required=True)
    parser.add_argument("--namespace", required=True)
    parser.add_argument("--days", type=int, default=364,
                         help="Audit lookback window in days (max ~364-365, OCI's retention limit)")
    parser.add_argument("--profile", default="DEFAULT")
    parser.add_argument("--region", default=None)
    args = parser.parse_args()

    clients = get_clients(args.profile, args.region)

    deleted_compartments = fetch_deleted_compartments(clients["identity"], args.compartment_id)
    audit_deletions = fetch_audit_deletions(clients["audit"], clients["identity"], args.compartment_id, args.days)

    document = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "note": (
            "One-time/periodic backfill of resources deleted before or outside of "
            "regular snapshot.py tracking. deleted_compartments is authoritative "
            "(directly from Identity API). audit_deletions is best-effort and may "
            "be incomplete depending on Audit service retention and event naming."
        ),
        "deleted_compartments": deleted_compartments,
        "audit_deletions": audit_deletions,
    }

    body = json.dumps(document, indent=2).encode("utf-8")
    clients["object_storage"].put_object(
        args.namespace, args.bucket, "historical-deletions.json", body
    )
    log.info("Uploaded historical-deletions.json to bucket '%s' (%d compartment deletions, "
              "%d audit deletion events)", args.bucket, len(deleted_compartments), len(audit_deletions))
    print(json.dumps(document, indent=2))


if __name__ == "__main__":
    main()
