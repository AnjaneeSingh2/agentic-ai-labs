"""
ask_oci_agent.py

Talk to an OCI Generative AI Agent (backed by your Knowledge Base) from the
command line. Handles session creation, multi-turn context, and streaming
off/on.

Prerequisites
-------------
1. pip install oci
2. A working OCI CLI config file at ~/.oci/config (or set OCI_CONFIG_PROFILE
   below), OR run on an OCI compute instance with Instance Principal auth
   enabled (see USE_INSTANCE_PRINCIPAL below).
3. The IAM policy allowing your user/group (or the instance principal) to
   use the agent endpoint, e.g.:
     allow group AgentUsers to use generative-ai-agent-family in compartment <name>
4. Your Agent Endpoint OCID (NOT the agent OCID, NOT the knowledge base OCID).
   Find it in OCI Console -> Analytics & AI -> Generative AI Agents ->
   Agents -> <your agent> -> Agent Endpoints -> <endpoint> -> OCID.

Usage
-----
    python ask_oci_agent.py

Then just type questions about your tenancy data. Type 'exit' or Ctrl+C to quit.

Special command: type 'resources' at the prompt to pull a live inventory of
every resource in your tenancy directly from OCI's Resource Search API
(bypasses the agent/knowledge base entirely - this always reflects what's
actually in your tenancy right now) and save it to resources.csv.
"""

import csv
import sys
import oci

# ---------------------------------------------------------------------------
# CONFIGURATION - edit these values for your tenancy
# ---------------------------------------------------------------------------

# The Agent Endpoint OCID (from Console: Generative AI Agents -> Agent Endpoints)
AGENT_ENDPOINT_ID = "ocid1.genaiagentendpoint.oc1.iad.amaaaaaah2vcsdqay2sgd4xeyndfc2b7p2fhz2f56gwladzeorqnb7rglamq"

# OCI config file profile to use (usually "DEFAULT" unless you set up multiple)
OCI_CONFIG_PROFILE = "DEFAULT"

# Set to True if running this from an OCI compute instance and want to use
# Instance Principal auth instead of a local config file/API key.
USE_INSTANCE_PRINCIPAL = False

# Set to True to stream the response token-by-token instead of waiting for
# the full answer.
SHOULD_STREAM = False

# Your tenancy OCID (Console -> Profile icon -> Tenancy: <name> -> copy OCID).
# Only needed for the 'resources' command below.
TENANCY_ID = "ocid1.tenancy.oc1..aaaaaaaabu6k373dxjtdouaasv5gsg2ra2eqgftnmy52sf7ozj2wytiwjdyq"


# ---------------------------------------------------------------------------
# Client setup
# ---------------------------------------------------------------------------

def get_client():
    if USE_INSTANCE_PRINCIPAL:
        signer = oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
        return oci.generative_ai_agent_runtime.GenerativeAiAgentRuntimeClient(
            config={}, signer=signer
        )
    else:
        config = oci.config.from_file(profile_name=OCI_CONFIG_PROFILE)
        return oci.generative_ai_agent_runtime.GenerativeAiAgentRuntimeClient(config)


def create_session(client, agent_endpoint_id):
    """Create a chat session so the agent keeps context across turns."""
    response = client.create_session(
        create_session_details=oci.generative_ai_agent_runtime.models.CreateSessionDetails(
            display_name="tenancy-qa-session",
            description="Session for asking questions about tenancy data",
        ),
        agent_endpoint_id=agent_endpoint_id,
    )
    return response.data.id


def ask(client, agent_endpoint_id, session_id, message):
    """Send one message to the agent and return the text answer."""
    chat_details = oci.generative_ai_agent_runtime.models.ChatDetails(
        user_message=message,
        session_id=session_id,
        should_stream=SHOULD_STREAM,
    )
    response = client.chat(
        agent_endpoint_id=agent_endpoint_id,
        chat_details=chat_details,
    )
    result = response.data

    # Pull out the plain-text answer
    answer_text = getattr(result, "message", None)
    if answer_text is not None and hasattr(answer_text, "content"):
        answer_text = getattr(answer_text.content, "text", None)
    if not answer_text:
        answer_text = str(result)

    # Optional: show citations / source documents used from the knowledge base
    citations = []
    try:
        for c in (result.citations or []):
            src_name = getattr(getattr(c, "source_location", None), "url", None) \
                or getattr(c, "source_text", None)
            if src_name:
                citations.append(src_name)
    except AttributeError:
        pass

    return answer_text, citations


# ---------------------------------------------------------------------------
# Direct tenancy resource inventory (bypasses the agent/knowledge base)
# ---------------------------------------------------------------------------

def get_search_client():
    if USE_INSTANCE_PRINCIPAL:
        signer = oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
        return oci.resource_search.ResourceSearchClient(config={}, signer=signer)
    else:
        config = oci.config.from_file(profile_name=OCI_CONFIG_PROFILE)
        return oci.resource_search.ResourceSearchClient(config)


def list_all_resources():
    """
    Query every resource across every compartment in the tenancy using the
    OCI Resource Search service. Requires a policy such as:
        allow group <YourGroup> to inspect all-resources in tenancy
    (use 'read' or 'use' instead of 'inspect' for more detail per resource type).
    """
    search_client = get_search_client()
    search_details = oci.resource_search.models.StructuredSearchDetails(
        query="query all resources",
        type="Structured",
    )

    resources = []
    response = search_client.search_resources(search_details)
    resources.extend(response.data.items)
    # Paginate through remaining pages
    while response.has_next_page:
        response = search_client.search_resources(
            search_details, page=response.next_page
        )
        resources.extend(response.data.items)

    return resources


def print_and_save_resources(resources, path="resources.csv"):
    print(f"\nFound {len(resources)} resources.\n")
    fields = ["display_name", "resource_type", "compartment_id",
              "lifecycle_state", "region", "identifier", "time_created"]

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(fields)
        for r in resources:
            row = [getattr(r, field, "") for field in fields]
            writer.writerow(row)
            print(f"  {row[1]:<28} {row[0]:<35} {row[3]:<12} {row[4]}")

    print(f"\nFull details saved to {path}\n")


# ---------------------------------------------------------------------------
# Main loop
# ---------------------------------------------------------------------------

def main():
    if "REPLACE_WITH_YOUR_ENDPOINT_OCID" in AGENT_ENDPOINT_ID:
        print("Set AGENT_ENDPOINT_ID at the top of this file to your agent's "
              "Agent Endpoint OCID before running.")
        sys.exit(1)

    client = get_client()
    session_id = create_session(client, AGENT_ENDPOINT_ID)
    print(f"Session started ({session_id}). Ask questions about your tenancy "
          f"data. Type 'exit' to quit.\n")

    while True:
        try:
            question = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nBye!")
            break

        if not question:
            continue
        if question.lower() in ("exit", "quit"):
            break

        if question.lower() in ("resources", "list resources"):
            if "REPLACE_WITH_YOUR_TENANCY_OCID" in TENANCY_ID:
                print("Set TENANCY_ID at the top of this file first "
                      "(Console -> Profile icon -> Tenancy -> copy OCID).\n")
                continue
            try:
                resources = list_all_resources()
                print_and_save_resources(resources)
            except oci.exceptions.ServiceError as e:
                print(f"OCI service error: {e.status} {e.code} - {e.message}")
            continue

        try:
            answer, citations = ask(client, AGENT_ENDPOINT_ID, session_id, question)
        except oci.exceptions.ServiceError as e:
            print(f"OCI service error: {e.status} {e.code} - {e.message}")
            continue

        print(f"\nAgent: {answer}\n")
        if citations:
            print("Sources:")
            for c in citations:
                print(f"  - {c}")
            print()


if __name__ == "__main__":
    main()
