import csv, os
import oci

TENANCY_ID = os.environ.get("TENANCY_ID", "ocid1.tenancy.oc1..aaaaaaaamfnmv4ola7zjuktdzg6xk3v4jc7aig4qq2t6pzjcrhzlyikiamra")
BUCKET_NAME = os.environ.get("BUCKET_NAME", "oci-change-tracker")
NAMESPACE = os.environ.get("NAMESPACE", "froqh6dvllfq")
REGION = os.environ.get("OCI_REGION", "eu-frankfurt-1")
CSV_PATH = "resources.csv"
NARRATIVE_PATH = "instance_narratives.txt"

FIELDS = [
    "display_name", "id", "compartment_id", "compartment_name", "lifecycle_state", "shape",
    "ocpus", "memory_in_gbs", "availability_domain", "fault_domain", "region", "image_id",
    "time_created", "freeform_tags", "defined_tags", "subnets", "private_ips", "public_ips",
    "nsg_ids", "boot_volume_id", "boot_volume_size_gbs", "boot_volume_vpus_per_gb",
    "boot_volume_kms_key_id", "boot_volume_backup_policy", "attached_volumes",
    "total_storage_gbs", "cpu_util_pct", "mem_util_pct", "net_bytes_in", "net_bytes_out",
]


def get_compartment_map(identity, tenancy_id):
    comps = oci.pagination.list_call_get_all_results(
        identity.list_compartments, tenancy_id, compartment_id_in_subtree=True, lifecycle_state="ACTIVE"
    ).data
    cmap = {c.id: c.name for c in comps}
    cmap[tenancy_id] = identity.get_tenancy(tenancy_id).data.name + " (root)"
    return cmap


def list_all_resources(search):
    q = oci.resource_search.models.StructuredSearchDetails(
        query="query instance resources", type="Structured", matching_context_type="NONE"
    )
    return oci.pagination.list_call_get_all_results(search.search_resources, q).data


def get_utilization(mon, comp_id, inst_id):
    out = {}
    for key, name in [("cpu_util_pct", "CpuUtilization"), ("mem_util_pct", "MemoryUtilization"),
                       ("net_bytes_in", "NetworksBytesIn"), ("net_bytes_out", "NetworksBytesOut")]:
        out[key] = ""
        try:
            q = f'{name}[1m]{{resourceId = "{inst_id}"}}.mean()'
            d = mon.summarize_metrics_data(comp_id, oci.monitoring.models.SummarizeMetricsDataDetails(
                namespace="oci_computeagent", query=q)).data
            if d and d[0].aggregated_datapoints:
                out[key] = d[0].aggregated_datapoints[-1].value
        except oci.exceptions.ServiceError:
            pass
    return out


def get_storage(inst, compute, bs):
    s = {"boot_volume_id": "", "boot_volume_size_gbs": "", "boot_volume_vpus_per_gb": "",
         "boot_volume_kms_key_id": "", "boot_volume_backup_policy": "", "attached_volumes": "",
         "total_storage_gbs": 0}
    try:
        boots = oci.pagination.list_call_get_all_results(
            compute.list_boot_volume_attachments, availability_domain=inst.availability_domain,
            compartment_id=inst.compartment_id, instance_id=inst.id).data
        if not boots:
            print(f"[storage] {inst.display_name}: no boot volume attachment found")
        else:
            bv = bs.get_boot_volume(boots[0].boot_volume_id).data
            s.update(boot_volume_id=bv.id, boot_volume_size_gbs=bv.size_in_gbs,
                      boot_volume_vpus_per_gb=bv.vpus_per_gb, boot_volume_kms_key_id=bv.kms_key_id or "")
            s["total_storage_gbs"] += bv.size_in_gbs or 0
            try:
                a = bs.get_volume_backup_policy_asset_assignment(bv.id).data
                s["boot_volume_backup_policy"] = a[0].policy_id if a else "None"
            except oci.exceptions.ServiceError as e:
                print(f"[storage] {inst.display_name}: backup policy lookup failed - {e.status} {e.code} {e.message}")
    except oci.exceptions.ServiceError as e:
        print(f"[storage] {inst.display_name}: boot volume lookup failed - {e.status} {e.code} {e.message}")
    try:
        vols = oci.pagination.list_call_get_all_results(
            compute.list_volume_attachments, compartment_id=inst.compartment_id, instance_id=inst.id).data
        parts = []
        for va in vols:
            try:
                v = bs.get_volume(va.volume_id).data
                parts.append(f"{v.display_name}:{v.id}:{v.size_in_gbs}GB:{v.vpus_per_gb}VPU")
                s["total_storage_gbs"] += v.size_in_gbs or 0
            except oci.exceptions.ServiceError as e:
                print(f"[storage] {inst.display_name}: attached volume lookup failed - {e.status} {e.code} {e.message}")
                parts.append(f"{va.display_name}:{va.volume_id}")
        s["attached_volumes"] = ";".join(parts)
    except oci.exceptions.ServiceError as e:
        print(f"[storage] {inst.display_name}: volume attachment list failed - {e.status} {e.code} {e.message}")
    return s


def enrich(summary, compute, vnic_c, bs, mon, comp_map):
    inst = compute.get_instance(summary.identifier).data
    row = {
        "display_name": inst.display_name, "id": inst.id, "compartment_id": inst.compartment_id,
        "compartment_name": comp_map.get(inst.compartment_id, ""), "lifecycle_state": inst.lifecycle_state,
        "shape": inst.shape, "ocpus": getattr(inst.shape_config, "ocpus", ""),
        "memory_in_gbs": getattr(inst.shape_config, "memory_in_gbs", ""),
        "availability_domain": inst.availability_domain, "fault_domain": inst.fault_domain,
        "region": inst.region, "image_id": inst.image_id, "time_created": inst.time_created,
        "freeform_tags": inst.freeform_tags, "defined_tags": inst.defined_tags,
        "subnets": "", "private_ips": "", "public_ips": "", "nsg_ids": "",
    }
    try:
        vnics = oci.pagination.list_call_get_all_results(
            compute.list_vnic_attachments, compartment_id=inst.compartment_id, instance_id=inst.id).data
        subnets, priv, pub, nsgs = [], [], [], []
        for va in vnics:
            if not va.vnic_id:
                continue
            v = vnic_c.get_vnic(va.vnic_id).data
            subnets.append(v.subnet_id or ""); priv.append(v.private_ip or "")
            pub.append(v.public_ip or ""); nsgs.extend(v.nsg_ids or [])
        row.update(subnets=";".join(subnets), private_ips=";".join(priv),
                   public_ips=";".join(pub), nsg_ids=";".join(nsgs))
    except oci.exceptions.ServiceError:
        pass
    row.update(get_storage(inst, compute, bs))
    row.update(get_utilization(mon, inst.compartment_id, inst.id))
    return row


def generate_narrative(resources: list) -> str:
    out = []
    for r in resources:
        n, kms = r["display_name"], r.get("boot_volume_kms_key_id")
        enc = f"customer-managed encryption with KMS key {kms}" if kms else "Oracle-managed default encryption"
        ips = f"Private IP(s): {r.get('private_ips') or 'none'}. Public IP(s): {r.get('public_ips') or 'none'}."
        vols = f"Additional attached volumes: {r['attached_volumes']}." if r.get("attached_volumes") \
            else "No additional attached volumes beyond its boot volume."
        util = f"CPU at {r.get('cpu_util_pct') or 'unknown'}%, memory at {r.get('mem_util_pct') or 'unknown'}%."
        out.append(
            f"{n} is a compute instance in the {r['compartment_name']} compartment, currently "
            f"{r['lifecycle_state']}, running on shape {r['shape']} with {r['ocpus']} OCPUs and "
            f"{r['memory_in_gbs']} GB memory in {r['availability_domain']}. {ips} "
            f"{n}'s boot volume is {r.get('boot_volume_size_gbs') or 'unknown'} GB with a performance tier "
            f"of {r.get('boot_volume_vpus_per_gb') or 'unknown'} VPUs/GB, backup policy "
            f"'{r.get('boot_volume_backup_policy') or 'None'}', and uses {enc}. {vols} "
            f"Total storage across boot and attached volumes: {r.get('total_storage_gbs', 0)} GB. "
            f"Recent utilization: {util}"
        )
    return "\n\n".join(out)


def print_and_save_resources(resources: list, path: str = "resources.csv"):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        w.writeheader()
        for r in resources:
            print(f"{r['display_name']:<30} {r['shape']:<25} {r['lifecycle_state']:<12} "
                  f"CPU%={r['cpu_util_pct']} Mem%={r['mem_util_pct']}")
            w.writerow(r)
    print(f"Saved {len(resources)} instance(s) to {path}")


def upload(os_client, local_path, object_name, title=None):
    # Attach a human-readable title as object metadata. Without this,
    # the agent's knowledge base has nothing to use as a citation title
    # and falls back to showing "unknown" in the console.
    meta = {"title": title or object_name}
    with open(local_path, "rb") as f:
        os_client.put_object(NAMESPACE, BUCKET_NAME, object_name, f, opc_meta=meta)
    print(f"Uploaded {object_name} to '{BUCKET_NAME}' (namespace '{NAMESPACE}') with title '{meta['title']}'.")


def trigger_ingestion(config, tenancy_id):
    data_source_id = os.environ.get("DATA_SOURCE_ID")
    if not data_source_id:
        print("DATA_SOURCE_ID not set; skipped triggering re-ingestion.")
        return False
    try:
        oci.generative_ai_agent.GenerativeAiAgentClient(config).create_data_ingestion_job(
            oci.generative_ai_agent.models.CreateDataIngestionJobDetails(
                compartment_id=os.environ.get("AGENT_COMPARTMENT_ID", tenancy_id),
                data_source_id=data_source_id, display_name="auto-ingest-after-report",
            ))
        print("Triggered knowledge base re-ingestion.")
        return True
    except oci.exceptions.ServiceError as e:
        print(f"Failed to trigger re-ingestion: {e}")
        return False


def main():
    config = oci.config.from_file()
    config["region"] = REGION
    search = oci.resource_search.ResourceSearchClient(config)
    compute = oci.core.ComputeClient(config)
    vnic_c = oci.core.VirtualNetworkClient(config)
    bs = oci.core.BlockstorageClient(config)
    mon = oci.monitoring.MonitoringClient(config)
    identity = oci.identity.IdentityClient(config)
    os_client = oci.object_storage.ObjectStorageClient(config)

    comp_map = get_compartment_map(identity, TENANCY_ID)
    print(f"Tenancy has {len(comp_map)} compartment(s): {', '.join(comp_map.values())}")

    found = list_all_resources(search)
    resources = [enrich(r, compute, vnic_c, bs, mon, comp_map) for r in found]
    print_and_save_resources(resources, CSV_PATH)
    upload(os_client, CSV_PATH, CSV_PATH, title="Compute Resources Inventory (CSV)")

    with open(NARRATIVE_PATH, "w", encoding="utf-8") as f:
        f.write(generate_narrative(resources))
    upload(os_client, NARRATIVE_PATH, NARRATIVE_PATH, title="Compute Instance Narratives")

    trigger_ingestion(config, TENANCY_ID)


if __name__ == "__main__":
    main()
