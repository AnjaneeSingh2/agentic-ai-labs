#!/usr/bin/env python3
"""
snapshot.py
============
End-to-end OCI change-detection agent.

What it does, every run:
  1. Authenticates to OCI (instance principal or local config file).
  2. Fetches current state of:
       - Compute instances
       - Block volumes
       - Boot volumes
       - Volume attachments (which volume is on which instance)
       - Compartments
       - VCNs
       - Subnets
     for a given compartment (optionally recursive into sub-compartments).
  3. Downloads the last known state ("latest.json") from an Object Storage
     bucket. If none exists, this run just becomes the baseline.
  4. Diffs old vs new state -> added / removed / modified resources.
  5. Uploads the new state back to Object Storage as:
       - latest.json                (always overwritten -> current truth)
       - history/<timestamp>.json   (immutable snapshot archive)
       - diffs/<timestamp>.json     (only written if something changed)
  6. Optionally publishes a summary to an OCI Notifications topic if
     changes were detected.

Usage:
  python3 snapshot.py \
      --compartment-id ocid1.tenancy.oc1..aaaaaaaabu6k373dxjtdouaasv5gsg2ra2eqgftnmy52sf7ozj2wytiwjdyq \
      --bucket oci-change-log \
      --namespace idsna7fjvtua \
      [--region us-ashburn-1] \
      [--instance-principal] \
      [--profile DEFAULT] \
      [--notification-topic-id ocid1.onstopic.oc1..xxxx] \
      [--recursive]

First run establishes the baseline. Schedule subsequent runs (cron,
OCI Functions + Resource Scheduler, etc.) to detect drift over time.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import logging
import sys
from datetime import datetime, timezone

import oci

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
)
log = logging.getLogger("snapshot")


# --------------------------------------------------------------------------
# Auth / client setup
# --------------------------------------------------------------------------

def get_clients(use_instance_principal: bool, profile: str, region: str | None):
    """Build all OCI SDK clients using one of two auth methods."""
    if use_instance_principal:
        log.info("Authenticating via Instance Principal")
        signer = oci.auth.signers.InstancePrincipalsSecurityTokenSigner()
        config = {}
        if region:
            config["region"] = region
        clients = {
            "compute": oci.core.ComputeClient(config={}, signer=signer),
            "blockstorage": oci.core.BlockstorageClient(config={}, signer=signer),
            "network": oci.core.VirtualNetworkClient(config={}, signer=signer),
            "object_storage": oci.object_storage.ObjectStorageClient(config={}, signer=signer),
            "ons": oci.ons.NotificationDataPlaneClient(config={}, signer=signer),
            "identity": oci.identity.IdentityClient(config={}, signer=signer),
        }
        if region:
            for c in clients.values():
                c.base_client.set_region(region)
        return clients

    log.info("Authenticating via local config file profile '%s'", profile)
    config = oci.config.from_file(profile_name=profile)
    if region:
        config["region"] = region
    return {
        "compute": oci.core.ComputeClient(config),
        "blockstorage": oci.core.BlockstorageClient(config),
        "network": oci.core.VirtualNetworkClient(config),
        "object_storage": oci.object_storage.ObjectStorageClient(config),
        "ons": oci.ons.NotificationDataPlaneClient(config),
        "identity": oci.identity.IdentityClient(config),
    }


# --------------------------------------------------------------------------
# Fetch current state
# --------------------------------------------------------------------------

def list_compartments(identity_client, root_compartment_id, recursive):
    if not recursive:
        return [root_compartment_id]
    comps = [root_compartment_id]
    response = oci.pagination.list_call_get_all_results(
        identity_client.list_compartments,
        root_compartment_id,
        compartment_id_in_subtree=True,
        lifecycle_state="ACTIVE",
    )
    comps.extend(c.id for c in response.data)
    return comps


def fetch_compartments(identity_client, root_compartment_id, recursive):
    """Record the compartments themselves as inventory items."""
    inventory = {}
    if not recursive:
        return inventory
    response = oci.pagination.list_call_get_all_results(
        identity_client.list_compartments,
        root_compartment_id,
        compartment_id_in_subtree=True,
        lifecycle_state="ACTIVE",
    )
    for comp in response.data:
        inventory[comp.id] = {
            "resource_type": "compartment",
            "display_name": comp.name,
            "lifecycle_state": comp.lifecycle_state,
            "description": comp.description,
            "compartment_id": comp.compartment_id,
            "time_created": str(comp.time_created),
            "freeform_tags": comp.freeform_tags or {},
            "defined_tags": comp.defined_tags or {},
        }
    return inventory


def fetch_instances(compute_client, compartment_ids):
    inventory = {}
    for cid in compartment_ids:
        items = oci.pagination.list_call_get_all_results(
            compute_client.list_instances, compartment_id=cid
        ).data
        for inst in items:
            inventory[inst.id] = {
                "resource_type": "compute_instance",
                "display_name": inst.display_name,
                "lifecycle_state": inst.lifecycle_state,
                "shape": inst.shape,
                "availability_domain": inst.availability_domain,
                "compartment_id": inst.compartment_id,
                "fault_domain": inst.fault_domain,
                "time_created": str(inst.time_created),
                "freeform_tags": inst.freeform_tags or {},
                "defined_tags": inst.defined_tags or {},
                "shape_config": {
                    "ocpus": getattr(inst.shape_config, "ocpus", None),
                    "memory_in_gbs": getattr(inst.shape_config, "memory_in_gbs", None),
                } if inst.shape_config else None,
            }
    return inventory


def fetch_block_volumes(blockstorage_client, compartment_ids):
    inventory = {}
    for cid in compartment_ids:
        items = oci.pagination.list_call_get_all_results(
            blockstorage_client.list_volumes, compartment_id=cid
        ).data
        for vol in items:
            inventory[vol.id] = {
                "resource_type": "block_volume",
                "display_name": vol.display_name,
                "lifecycle_state": vol.lifecycle_state,
                "size_in_gbs": vol.size_in_gbs,
                "vpus_per_gb": vol.vpus_per_gb,
                "availability_domain": vol.availability_domain,
                "compartment_id": vol.compartment_id,
                "time_created": str(vol.time_created),
                "is_hydrated": getattr(vol, "is_hydrated", None),
                "kms_key_id": vol.kms_key_id,
                "freeform_tags": vol.freeform_tags or {},
                "defined_tags": vol.defined_tags or {},
            }
    return inventory


def fetch_boot_volumes_full(blockstorage_client, availability_domains, compartment_ids):
    """Boot volumes are listed per Availability Domain + compartment."""
    inventory = {}
    for cid in compartment_ids:
        for ad in availability_domains:
            items = oci.pagination.list_call_get_all_results(
                blockstorage_client.list_boot_volumes,
                availability_domain=ad,
                compartment_id=cid,
            ).data
            for bv in items:
                inventory[bv.id] = {
                    "resource_type": "boot_volume",
                    "display_name": bv.display_name,
                    "lifecycle_state": bv.lifecycle_state,
                    "size_in_gbs": bv.size_in_gbs,
                    "vpus_per_gb": bv.vpus_per_gb,
                    "availability_domain": bv.availability_domain,
                    "compartment_id": bv.compartment_id,
                    "time_created": str(bv.time_created),
                    "kms_key_id": bv.kms_key_id,
                    "freeform_tags": bv.freeform_tags or {},
                    "defined_tags": bv.defined_tags or {},
                }
    return inventory


def fetch_volume_attachments(compute_client, compartment_ids):
    inventory = {}
    for cid in compartment_ids:
        items = oci.pagination.list_call_get_all_results(
            compute_client.list_volume_attachments, compartment_id=cid
        ).data
        for att in items:
            inventory[att.id] = {
                "resource_type": "volume_attachment",
                "display_name": att.display_name,
                "lifecycle_state": att.lifecycle_state,
                "instance_id": att.instance_id,
                "volume_id": att.volume_id,
                "attachment_type": att.attachment_type,
                "compartment_id": att.compartment_id,
                "time_created": str(att.time_created),
            }
    return inventory


def fetch_vcns(network_client, compartment_ids):
    inventory = {}
    for cid in compartment_ids:
        items = oci.pagination.list_call_get_all_results(
            network_client.list_vcns, compartment_id=cid
        ).data
        for vcn in items:
            inventory[vcn.id] = {
                "resource_type": "vcn",
                "display_name": vcn.display_name,
                "lifecycle_state": vcn.lifecycle_state,
                "cidr_blocks": getattr(vcn, "cidr_blocks", None) or [getattr(vcn, "cidr_block", None)],
                "compartment_id": vcn.compartment_id,
                "time_created": str(vcn.time_created),
                "dns_label": vcn.dns_label,
                "freeform_tags": vcn.freeform_tags or {},
                "defined_tags": vcn.defined_tags or {},
            }
    return inventory


def fetch_subnets(network_client, compartment_ids):
    inventory = {}
    for cid in compartment_ids:
        items = oci.pagination.list_call_get_all_results(
            network_client.list_subnets, compartment_id=cid
        ).data
        for sn in items:
            inventory[sn.id] = {
                "resource_type": "subnet",
                "display_name": sn.display_name,
                "lifecycle_state": sn.lifecycle_state,
                "cidr_block": sn.cidr_block,
                "vcn_id": sn.vcn_id,
                "compartment_id": sn.compartment_id,
                "availability_domain": sn.availability_domain,
                "time_created": str(sn.time_created),
                "prohibit_public_ip_on_vnic": sn.prohibit_public_ip_on_vnic,
                "freeform_tags": sn.freeform_tags or {},
                "defined_tags": sn.defined_tags or {},
            }
    return inventory


def build_inventory(clients, root_compartment_id, recursive):
    log.info("Enumerating compartments (recursive=%s)", recursive)
    compartment_ids = list_compartments(clients["identity"], root_compartment_id, recursive)
    log.info("Scanning %d compartment(s)", len(compartment_ids))

    ads = clients["identity"].list_availability_domains(
        compartment_id=root_compartment_id
    ).data
    ad_names = [ad.name for ad in ads]

    inventory = {}
    inventory.update(fetch_compartments(clients["identity"], root_compartment_id, recursive))
    inventory.update(fetch_instances(clients["compute"], compartment_ids))
    inventory.update(fetch_block_volumes(clients["blockstorage"], compartment_ids))
    inventory.update(fetch_boot_volumes_full(clients["blockstorage"], ad_names, compartment_ids))
    inventory.update(fetch_volume_attachments(clients["compute"], compartment_ids))
    inventory.update(fetch_vcns(clients["network"], compartment_ids))
    inventory.update(fetch_subnets(clients["network"], compartment_ids))

    log.info("Collected %d total resources", len(inventory))
    return {
        "collected_at": datetime.now(timezone.utc).isoformat(),
        "root_compartment_id": root_compartment_id,
        "resources": inventory,
    }


# --------------------------------------------------------------------------
# Object Storage read/write
# --------------------------------------------------------------------------

LATEST_OBJECT_NAME = "latest.json"


def load_previous_snapshot(object_storage_client, namespace, bucket):
    try:
        resp = object_storage_client.get_object(namespace, bucket, LATEST_OBJECT_NAME)
        data = json.loads(resp.data.content.decode("utf-8"))
        log.info("Loaded previous snapshot from %s (collected_at=%s)", LATEST_OBJECT_NAME,
                  data.get("collected_at"))
        return data
    except oci.exceptions.ServiceError as e:
        if e.status == 404:
            log.info("No previous snapshot found (%s) -- this run establishes the baseline",
                      LATEST_OBJECT_NAME)
            return None
        raise


def save_snapshot(object_storage_client, namespace, bucket, snapshot: dict):
    body = json.dumps(snapshot, indent=2).encode("utf-8")

    # Overwrite the "current truth" pointer.
    object_storage_client.put_object(namespace, bucket, LATEST_OBJECT_NAME, body)

    # Archive an immutable, timestamped copy.
    ts = snapshot["collected_at"].replace(":", "-")
    history_name = f"history/{ts}.json"
    object_storage_client.put_object(namespace, bucket, history_name, body)

    log.info("Saved snapshot to %s and %s", LATEST_OBJECT_NAME, history_name)
    return history_name


def save_diff(object_storage_client, namespace, bucket, diff: dict, timestamp: str):
    body = json.dumps(diff, indent=2).encode("utf-8")
    name = f"diffs/{timestamp.replace(':', '-')}.json"
    object_storage_client.put_object(namespace, bucket, name, body)
    log.info("Saved diff report to %s", name)
    return name


# --------------------------------------------------------------------------
# Diff logic
# --------------------------------------------------------------------------

def _checksum(resource: dict) -> str:
    return hashlib.sha256(json.dumps(resource, sort_keys=True).encode()).hexdigest()


def diff_snapshots(old_snapshot, new_snapshot):
    old_resources = old_snapshot["resources"] if old_snapshot else {}
    new_resources = new_snapshot["resources"]

    old_ids = set(old_resources)
    new_ids = set(new_resources)

    added = sorted(new_ids - old_ids)
    removed = sorted(old_ids - new_ids)
    common = old_ids & new_ids

    modified = []
    for rid in sorted(common):
        old_r, new_r = old_resources[rid], new_resources[rid]
        if _checksum(old_r) != _checksum(new_r):
            changed_fields = {}
            for key in set(old_r) | set(new_r):
                if old_r.get(key) != new_r.get(key):
                    changed_fields[key] = {"old": old_r.get(key), "new": new_r.get(key)}
            modified.append({"id": rid, "resource_type": new_r.get("resource_type"),
                              "changes": changed_fields})

    result = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "added": [{"id": rid, "resource_type": new_resources[rid]["resource_type"],
                    "display_name": new_resources[rid].get("display_name")} for rid in added],
        "removed": [{"id": rid, "resource_type": old_resources[rid]["resource_type"],
                      "display_name": old_resources[rid].get("display_name")} for rid in removed],
        "modified": modified,
    }
    result["has_changes"] = bool(result["added"] or result["removed"] or result["modified"])
    return result


# --------------------------------------------------------------------------
# Notification
# --------------------------------------------------------------------------

def notify(ons_client, topic_id, diff: dict):
    lines = [
        f"OCI change detected at {diff['generated_at']}",
        f"  Added:    {len(diff['added'])}",
        f"  Removed:  {len(diff['removed'])}",
        f"  Modified: {len(diff['modified'])}",
        "",
    ]
    for r in diff["added"]:
        lines.append(f"[+] {r['resource_type']} {r['display_name']} ({r['id']})")
    for r in diff["removed"]:
        lines.append(f"[-] {r['resource_type']} {r['display_name']} ({r['id']})")
    for r in diff["modified"]:
        lines.append(f"[~] {r['resource_type']} {r['id']} changed fields: {list(r['changes'])}")

    message = "\n".join(lines)
    ons_client.publish_message(
        topic_id,
        oci.ons.models.MessageDetails(
            title="OCI Resource Change Detected",
            body=message,
        ),
    )
    log.info("Published notification to topic %s", topic_id)


# --------------------------------------------------------------------------
# Main
# --------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="OCI change-detection snapshot agent")
    parser.add_argument("--compartment-id", required=True)
    parser.add_argument("--bucket", required=True)
    parser.add_argument("--namespace", required=True, help="Object Storage namespace")
    parser.add_argument("--region", default=None)
    parser.add_argument("--instance-principal", action="store_true",
                         help="Use instance principal auth instead of a config file")
    parser.add_argument("--profile", default="DEFAULT", help="~/.oci/config profile name")
    parser.add_argument("--notification-topic-id", default=None,
                         help="OCID of an ONS topic to publish change alerts to")
    parser.add_argument("--recursive", action="store_true",
                         help="Also scan sub-compartments of --compartment-id")
    args = parser.parse_args()

    clients = get_clients(args.instance_principal, args.profile, args.region)

    new_snapshot = build_inventory(clients, args.compartment_id, args.recursive)
    old_snapshot = load_previous_snapshot(clients["object_storage"], args.namespace, args.bucket)
    diff = diff_snapshots(old_snapshot, new_snapshot)

    save_snapshot(clients["object_storage"], args.namespace, args.bucket, new_snapshot)

    if diff["has_changes"]:
        log.info("CHANGES DETECTED: +%d added, -%d removed, ~%d modified",
                  len(diff["added"]), len(diff["removed"]), len(diff["modified"]))
        save_diff(clients["object_storage"], args.namespace, args.bucket, diff, diff["generated_at"])
        if args.notification_topic_id:
            notify(clients["ons"], args.notification_topic_id, diff)
    else:
        log.info("No changes detected since last run.")

    print(json.dumps(diff, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())