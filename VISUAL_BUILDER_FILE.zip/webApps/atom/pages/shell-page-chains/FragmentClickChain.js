define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class FragmentClickChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $page, $flow, $application } = context;

      const navigateToFlowMainResult = await Actions.navigateToFlow(context, {
        flow: 'main',
        page: 'main-test',
      });
    }
  }

  return FragmentClickChain;
});
