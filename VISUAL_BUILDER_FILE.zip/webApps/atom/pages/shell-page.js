define([ 'resources/native-client-sdk-js/web-sdk'], ( WebSDK) => {
  'use strict';

  class PageModule {
  }
  
  return PageModule;
});
