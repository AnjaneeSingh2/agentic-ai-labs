define([
  'vb/action/actionChain',
  'vb/action/actions',
  'vb/action/actionUtils',
], (
  ActionChain,
  Actions,
  ActionUtils
) => {
  'use strict';

  class ButtonActionChain extends ActionChain {

    /**
     * @param {Object} context
     */
    async run(context) {
      const { $fragment, $application } = context;

      await Actions.openUrl(context, {
        url: 'https://www.wrike.com/form/eyJhY2NvdW50SWQiOjQwMjU5ODUsInRhc2tGb3JtSWQiOjExODQ3OTR9CTQ4NTU2NDA2Nzc3MzUJNzk4OWQ2OWUwMWM3NDE5ZGYwMjU4MGVjZWNjYzZkNzE1NWJjYWM3ZDUzOTc2YzM4MDYzOWE1NmVlMGQzZGRiZQ==',
        windowName: '_blank',
      });
    }
  }

  return ButtonActionChain;
});
