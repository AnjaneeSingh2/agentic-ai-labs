requirejs.config({bundles: {
    "oj-oda/oj-oda-component-bundle": [
        "oj-oda/ask-oracle-chat/loader"
    ]}
});