# oj-oda Component Pack

This package contains ojet components from Oracle Digital Assistant (ODA) team to enable ODA interactions with OJET applications

This package contains the following components

- oj-oda-ask-oracle-chat

