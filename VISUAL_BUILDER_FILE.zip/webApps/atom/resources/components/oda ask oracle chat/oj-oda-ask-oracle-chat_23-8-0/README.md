# Ask Oracle Chat

`<oj-oda-ask-oracle-chat>` provides a OJET component for integrating Oracle Digital Assistant Chat with OJET and VB based applications.

## Browser Support
The Component is supported on following browsers in Mac, Windows, and Linux:
* Firefox
* Chrome
* Safari
* Edge

For mobile platforms, following browsers are supported:
* Android browser
* iOS Safari

Internet Explorer is not officially supported by the Chat Component.

## Features
* Manages the connection between ODA skill and chat UI.
* Provides APIs to connect, disconnect from skill and send messages.
* Provides configuration to save and clear conversation history.

## Properties

### `config`
Chat configuration to be used to initialize the SDK. You can pass the following properties.
- `uri`: The server URI is the hostname of the ODA server to which component will connect.
- `channelId`: Id of the Web channel to which component will connect.
- `userId`: An optional id which is used to identify the user.
- `initUserProfile`: An optional user profile message sent to skill after skill connection without being displayed in chat widget.
- `initUserHiddenMessage`: A hidden user message to send once the chat widget is connected to the skill to initiate the conversation automatically.
- `enableLocalConversationHistory`: Config flag to configure whether to save conversation history locally.

### `enableSpeechAutoSend`
Setting to enable auto send of messages after voice recognition

### `showBackBtn`
Config flag to show/hide back button

### `userAvatar`
Config object for user avatar. You can pass the following properties.
- `src`: Source url string for avatar image.
- `initials`: Initial string to be shown if no image source available.

## Example
In your js file

```js
import 'oj-oda/ask-oracle-chat/loader';

class RootViewModel {
    .......
    chatConfig = {
        uri: '<odaInstanceURI>',
        channelId: '<odaChannelId>',
        userId: '<odaUserId>',
    }
    .......
}
```

In your html file

```html
<oj-oda-ask-oracle-chat 
          id="ask-oracle-chat"
          config="[[chatConfig]]"
          show-back-btn="true"
          user-avatar="[[userAvatar]]">
</oj-oda-ask-oracle-chat>
```

