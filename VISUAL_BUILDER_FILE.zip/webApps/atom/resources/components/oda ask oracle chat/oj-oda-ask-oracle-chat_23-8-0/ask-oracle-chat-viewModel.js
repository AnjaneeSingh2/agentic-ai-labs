define(["require", "exports", "@oda-web-sdk/oda-core", "knockout", "./utils", "ojs/ojcontext", "ojs/ojlogger", "ojs/ojknockout", "oj-sp/chat-container/loader", "oj-sp/chat-text/loader", "oj-sp/chat-card/loader", "oj-sp/chat-message-block/loader", "oj-sp/chat-input/loader"], function (require, exports, oda_core_1, ko, utils_1, Context, Logger) {
    /* eslint-disable @typescript-eslint/no-explicit-any */
    /* eslint-disable no-loop-func */
    'use strict';
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.ErrorType = void 0;
    exports.ErrorType = {
        Error: 'error',
        Warning: 'warning'
    };
    const MESSAGE_BLOCK_THRESOLD = 10000;
    const STAMPING_INTERVAL = 3600000;
    const TYPING_CUE_TIMER = 3000;
    const TYPING_CUE_TIMEOUT = 90000;
    class ViewModel {
        constructor(context) {
            this.lastMsgTime = 0;
            this.lastStampTime = 0;
            this.lastMsgSender = oda_core_1.SenderType.User;
            this.elemId = 'oda-chat';
            this.isInitMessageSent = false;
            this.isConnecting = false;
            this.initCore = (config) => {
                if (config.enableLocalConversationHistory) {
                    this.storageKey = `${config.channelId}-${config.userId}-messages_FND-userInfo`;
                    const messages = this.getMessages();
                    this.messages(messages.map(messageBlock => (Object.assign(Object.assign({}, messageBlock), { fromHistory: true }))));
                }
                this.core = new oda_core_1.WebCore({
                    URI: config === null || config === void 0 ? void 0 : config.uri,
                    channelId: config === null || config === void 0 ? void 0 : config.channelId,
                    userId: config === null || config === void 0 ? void 0 : config.userId,
                    enableAttachment: true,
                    isTLS: true,
                    retryMaxAttempts: 0
                });
                this.core.on(oda_core_1.CoreEvent.MessageReceived, this.receiveMessage);
            };
            this.getLastMessageBlock = () => {
                const messages = this.messages();
                return messages[messages.length - 1];
            };
            this.updateMessageList = (messagePayload, sender) => {
                const date = new Date();
                const timeNow = date.getTime();
                const lastMessageBlock = this.getLastMessageBlock();
                let messageBlock;
                if (lastMessageBlock && sender === this.lastMsgSender &&
                    MESSAGE_BLOCK_THRESOLD && MESSAGE_BLOCK_THRESOLD > timeNow - this.lastMsgTime) {
                    lastMessageBlock.messages.push(messagePayload);
                    this.messages.replace(lastMessageBlock, Object.assign({}, lastMessageBlock));
                    if (this.storageKey) {
                        this.saveMessages();
                    }
                }
                else {
                    messageBlock = {
                        sender: sender,
                        messages: [messagePayload]
                    };
                    this.addMessageBlock(messageBlock);
                }
                if (timeNow - this.lastStampTime > STAMPING_INTERVAL) {
                    messageBlock.timestamp = date;
                    this.lastStampTime = Date.now();
                }
            };
            this.showTypingCue = (delay) => {
                this.typingCueTimer = setTimeout(() => {
                    const lastMessageBlock = this.getLastMessageBlock();
                    // Show typing cue only if last message is not a typing cue, or it's connecting
                    if (lastMessageBlock && (lastMessageBlock === null || lastMessageBlock === void 0 ? void 0 : lastMessageBlock.messages) || !lastMessageBlock) {
                        this.messages.push({
                            sender: oda_core_1.SenderType.Skill
                        });
                        this.typingCueTimeoutTimer = setTimeout(() => {
                            const lastMessageBlockInner = this.getLastMessageBlock();
                            if (lastMessageBlockInner && !lastMessageBlockInner.messages) {
                                this.messages.replace(lastMessageBlockInner, {
                                    sender: oda_core_1.SenderType.Skill,
                                    messages: [
                                        {
                                            type: oda_core_1.MessageType.Text,
                                            text: 'Sorry, but I’m not finding anything in response to your request.'
                                        }
                                    ]
                                });
                            }
                        }, TYPING_CUE_TIMEOUT);
                    }
                }, delay >= 0 ? delay : TYPING_CUE_TIMER);
            };
            this.hideTypingCue = () => {
                const lastMessageBlock = this.getLastMessageBlock();
                if (lastMessageBlock && !lastMessageBlock.messages) {
                    this.messages.pop();
                }
                clearTimeout(this.typingCueTimer);
                clearTimeout(this.typingCueTimeoutTimer);
            };
            this.getMessages = () => {
                const savedMessages = localStorage.getItem(this.storageKey);
                if (savedMessages) {
                    const messages = JSON.parse(savedMessages);
                    messages.forEach(messageBlock => {
                        if (messageBlock.timestamp) {
                            messageBlock.timestamp = new Date(messageBlock.timestamp);
                        }
                    });
                    return messages;
                }
                return [];
            };
            this.saveMessages = () => {
                localStorage.setItem(this.storageKey, JSON.stringify(this.messages()));
            };
            this.addMessageBlock = (messageBlock) => {
                this.messages.push(messageBlock);
                this.lastMsgTime = Date.now();
                this.lastMsgSender = messageBlock.sender;
                if (this.storageKey) {
                    this.saveMessages();
                }
            };
            this.handleInputChange = (event) => {
                var _a;
                const query = event.detail.value;
                if (query && query.length > 2) {
                    (_a = this.core) === null || _a === void 0 ? void 0 : _a.getSuggestions(query).then(suggestions => {
                        this.suggestionData(suggestions.map((sug, i) => ({ key: i,
                            value: sug })));
                    });
                }
            };
            this.handleBack = (event) => {
                this.suggestionData([]);
                this.hideTypingCue();
                this.composite.dispatchEvent(new CustomEvent('ojOdaBackAction', {
                    bubbles: event.bubbles,
                    cancelable: event.cancelable,
                    composed: event.composed
                }));
            };
            this.startRecording = () => {
                var _a;
                const inputElem = document.getElementById(`${this.elemId}_input`);
                (_a = this.core) === null || _a === void 0 ? void 0 : _a.startRecognition({
                    onRecognitionText: (data) => {
                        switch (data.type) {
                            case 'error':
                                Logger.error('Failed to recognize voice', data.text);
                                break;
                            case 'final':
                                inputElem.setChatInputMode('text');
                                this.stopRecording();
                                this.userInput(data.text);
                                if (this.properties.enableSpeechAutoSend) {
                                    this.sendMessage(this.userInput());
                                    this.userInput('');
                                }
                                break;
                            case 'partial':
                                this.userInput(data.text);
                                break;
                        }
                    },
                    onVisualData: (values) => {
                        const visualizerCanvas = document.getElementById('oda_voice_visualizer');
                        (0, utils_1.drawVisualizer)(values, visualizerCanvas, '#161513');
                    }
                }).then(() => {
                    Logger.info('Recognition started');
                }).catch((error) => {
                    inputElem.setChatInputMode('text');
                    this.updateMessageList({
                        type: exports.ErrorType.Error,
                        errorMessageCode: error.message
                    }, oda_core_1.SenderType.User);
                });
            };
            this.stopRecording = () => {
                var _a;
                this.userInput('');
                (_a = this.core) === null || _a === void 0 ? void 0 : _a.stopRecognition();
            };
            this.toggleVoiceMode = (event) => {
                this.startRecording();
                event.detail.endVoiceCallback.then(() => {
                    this.stopRecording();
                });
            };
            this.handleValueEnter = (event) => {
                const userMessage = event.detail.value;
                this.sendMessage(userMessage);
            };
            this.sendMessage = (message, isHidden = false) => {
                var _a;
                this.hideTypingCue();
                return (_a = this.core) === null || _a === void 0 ? void 0 : _a.sendMessage(message, { sdkMetadata: { channelSubtype: 'redwood' } }).then((userMessageResult) => {
                    if (!isHidden) {
                        this.updateMessageList(userMessageResult.messagePayload, oda_core_1.SenderType.User);
                        this.showTypingCue();
                    }
                    return userMessageResult;
                }, error => {
                    this.updateMessageList({
                        type: exports.ErrorType.Error,
                        errorMessageCode: error.message
                    }, oda_core_1.SenderType.User);
                });
            };
            this.sendAttachment = (event) => {
                var _a;
                const fileList = event.detail.selectedFiles;
                const fileListLength = fileList.length;
                const date = new Date();
                const timeNow = date.getTime();
                let uploadMessageBlock;
                const uploadMessages = [];
                this.hideTypingCue();
                if (fileListLength) {
                    for (let i = 0; i < fileListLength; i++) {
                        const file = fileList[i];
                        const fileName = file.name;
                        const attachmentPayload = {
                            type: oda_core_1.MessageType.Attachment,
                            attachment: {
                                type: file.type,
                                url: '',
                                title: fileName
                            }
                        };
                        uploadMessages.push(attachmentPayload);
                        (_a = this.core) === null || _a === void 0 ? void 0 : _a.sendAttachment(file, { sdkMetadata: { channelSubtype: 'redwood' } }).then((userMessage) => {
                            const userAttachmentPayload = userMessage.messagePayload;
                            const updatedAttachment = Object.assign(Object.assign({}, userAttachmentPayload.attachment), { title: fileName, size: file.size, type: file.type });
                            uploadMessages.splice(i, 1, Object.assign(Object.assign({}, userAttachmentPayload), { attachment: updatedAttachment }));
                            this.messages.replace(uploadMessageBlock, Object.assign(Object.assign({}, uploadMessageBlock), { messages: uploadMessages }));
                            if (this.storageKey) {
                                this.saveMessages();
                            }
                            this.showTypingCue();
                        }, (error) => {
                            uploadMessages.splice(i, 1, {
                                type: exports.ErrorType.Error,
                                errorMessageCode: error.message,
                                errorTitle: fileName
                            });
                            this.messages.replace(uploadMessageBlock, Object.assign(Object.assign({}, uploadMessageBlock), { messages: uploadMessages }));
                            if (this.storageKey) {
                                this.saveMessages();
                            }
                        });
                    }
                    uploadMessageBlock = {
                        sender: oda_core_1.SenderType.User,
                        messages: uploadMessages
                    };
                    if (timeNow - this.lastStampTime > STAMPING_INTERVAL) {
                        uploadMessageBlock.timestamp = date;
                        this.lastStampTime = Date.now();
                    }
                    this.addMessageBlock(uploadMessageBlock);
                }
            };
            this.receiveMessage = (message) => {
                var _a, _b;
                const messagePayload = message.messagePayload;
                if (messagePayload.type === oda_core_1.MessageType.Card) {
                    const actions = ((_a = messagePayload.actions) === null || _a === void 0 ? void 0 : _a.length) ? messagePayload.actions : [];
                    const globalActions = ((_b = messagePayload.globalActions) === null || _b === void 0 ? void 0 : _b.length) ? [...actions, ...messagePayload.globalActions] : [...actions];
                    if (globalActions.length) {
                        messagePayload.globalActions = globalActions;
                    }
                }
                this.hideTypingCue();
                this.updateMessageList(messagePayload, oda_core_1.SenderType.Skill);
            };
            this.handleAction = (event) => {
                const action = event.detail;
                let label = '';
                if (action.postback && action.postback.action === 'retry') {
                    this.lastStampTime = 0;
                    this.replaceWithTypingCue();
                    this.connect().catch(e => {
                        Logger.error('Failed to connect', e);
                    });
                }
                else {
                    this.hideTypingCue();
                    if (action.type === oda_core_1.MessageType.FormSubmission && action.label) {
                        label = action.label;
                        delete action.label;
                    }
                    this.sendMessage(action, true).then((userMessage) => {
                        if (userMessage && !userMessage.messagePayload.partialSubmitField) {
                            if (label) {
                                userMessage.messagePayload.text = label;
                            }
                            userMessage.messagePayload.type = oda_core_1.MessageType.Text;
                            this.updateMessageList(userMessage.messagePayload, oda_core_1.SenderType.User);
                        }
                        this.showTypingCue();
                    });
                }
            };
            this.replaceWithTypingCue = () => {
                const lastMessageBlock = this.getLastMessageBlock();
                this.messages.replace(lastMessageBlock, Object.assign(Object.assign({}, lastMessageBlock), { messages: null }));
                if (this.storageKey) {
                    this.saveMessages();
                }
            };
            this.connect = (config) => {
                var _a, _b;
                this.showTypingCue(0);
                if (!((_a = this.core) === null || _a === void 0 ? void 0 : _a.isConnected()) && !this.isConnecting) {
                    this.isConnecting = true;
                    return (_b = this.core) === null || _b === void 0 ? void 0 : _b.connect().then(() => {
                        var _a;
                        Logger.info('Connected to the server');
                        const userProfile = this.properties.config.initUserProfile;
                        this.hideTypingCue();
                        this.isConnecting = false;
                        this.isConnected(true);
                        // Update user profile if configured
                        if (userProfile) {
                            (_a = this.core) === null || _a === void 0 ? void 0 : _a.updateUser(userProfile, { sdkMetadata: { channelSubtype: 'redwood' } }).then(() => {
                                this.sendInitMessage(config === null || config === void 0 ? void 0 : config.message);
                            }, err => Promise.reject(err));
                        }
                        else {
                            this.sendInitMessage(config === null || config === void 0 ? void 0 : config.message);
                        }
                    }, err => {
                        this.isConnecting = false;
                        this.hideTypingCue();
                        this.updateMessageList({
                            type: oda_core_1.MessageType.Text,
                            text: '',
                            translationId: oda_core_1.CoreError.ConnectionNone,
                            globalActions: [
                                {
                                    type: oda_core_1.ActionType.Postback,
                                    label: 'Try Again',
                                    postback: {
                                        action: 'retry'
                                    }
                                }
                            ]
                        }, oda_core_1.SenderType.Skill);
                        return Promise.reject(err);
                    });
                }
                return Promise.reject(new Error('Already connected'));
            };
            this.sendInitMessage = (initMessage) => {
                const initUserHiddenMessage = this.properties.config.initUserHiddenMessage;
                // Send initMessage if passed or else send initUserHiddenMessage if configured and not already sent
                if (initMessage) {
                    this.sendMessage(initMessage).then(() => {
                        this.isInitMessageSent = true;
                    });
                }
                else if (initUserHiddenMessage && !this.isInitMessageSent) {
                    this.sendMessage(initUserHiddenMessage, true).then((userMessage) => {
                        if (userMessage) {
                            this.isInitMessageSent = true;
                            this.showTypingCue();
                        }
                    });
                }
            };
            this.setUserInput = (message) => {
                this.userInput(message);
            };
            this.clearConversationHistory = () => {
                this.messages.removeAll();
                localStorage.removeItem(this.storageKey);
            };
            this.disconnect = () => {
                var _a;
                return (_a = this.core) === null || _a === void 0 ? void 0 : _a.disconnect().then(() => {
                    this.isConnected(false);
                    Logger.info('Disconnected from the server');
                }).catch(() => {
                    Logger.error('Failed to disconnect');
                });
            };
            // At the start of your viewModel constructor
            const elementContext = Context.getContext(context.element);
            const busyContext = elementContext.getBusyContext();
            const options = { 'description': 'Web Component Startup - Waiting for data' };
            this.busyResolve = busyContext.addBusyState(options);
            this.composite = context.element;
            // Example observable
            this.properties = context.properties;
            this.userInput = ko.observable('');
            this.messages = ko.observableArray([]);
            this.suggestionData = ko.observableArray([]);
            this.elemId = context.uniqueId;
            this.isConnected = ko.observable(false);
            /*
             * Example for parsing context properties
             * if (context.properties.name) {
             *     parse the context properties here
             * }
             */
            // Once all startup and async activities have finished, relocate if there are any async activities
            this.busyResolve();
        }
        // Lifecycle methods - implement if necessary
        bindingsApplied(context) {
            this.initCore(context.properties.config);
        }
        propertyChanged(context) {
            var _a;
            if (context.property === 'config') {
                (_a = this.core) === null || _a === void 0 ? void 0 : _a.destroy();
                this.initCore(context.value);
            }
        }
        disconnected() {
            var _a;
            (_a = this.core) === null || _a === void 0 ? void 0 : _a.disconnect().then(() => {
                this.isConnected(false);
                Logger.info('Disconnected');
            }).catch(() => {
                Logger.error('Failed to disconnect');
            });
        }
    }
    exports.default = ViewModel;
});
//# sourceMappingURL=ask-oracle-chat-viewModel.js.map