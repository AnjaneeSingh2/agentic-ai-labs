# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/).

## [23.8.0] - 2023-08-08

### Added
- Initial version of the component.
- Support for ODA CMM payloads including Editable Forms.
- Support for Local Conversation History