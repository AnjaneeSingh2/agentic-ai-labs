define(["require", "exports", "ojs/ojcomposite", "text!./ask-oracle-chat-view.html", "./ask-oracle-chat-viewModel", "text!./component.json", "css!./ask-oracle-chat-styles.css"], function (require, exports, Composite, view, ask_oracle_chat_viewModel_1, metadata) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    Composite.register('oj-oda-ask-oracle-chat', {
        view: view,
        viewModel: ask_oracle_chat_viewModel_1.default,
        metadata: JSON.parse(metadata)
    });
});
//# sourceMappingURL=loader.js.map