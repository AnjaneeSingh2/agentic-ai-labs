import 'css!./ask-oracle-chat-styles.css';
declare global {
    namespace preact.JSX {
        interface IntrinsicElements {
            'oj-oda-ask-oracle-chat': any;
        }
    }
}
