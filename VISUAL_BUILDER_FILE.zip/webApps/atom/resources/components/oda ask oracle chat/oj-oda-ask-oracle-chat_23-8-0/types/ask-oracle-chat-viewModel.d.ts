import { Action, Message, MessagePayload, SenderType, UserMessage, UserProfileMessage, WebCore } from '@oda-web-sdk/oda-core';
import * as ko from 'knockout';
import Composite = require('ojs/ojcomposite');
import 'ojs/ojknockout';
import 'oj-sp/chat-container/loader';
import 'oj-sp/chat-text/loader';
import 'oj-sp/chat-card/loader';
import 'oj-sp/chat-message-block/loader';
import 'oj-sp/chat-input/loader';
export declare const ErrorType: {
    readonly Error: "error";
    readonly Warning: "warning";
};
export type ErrorType = typeof ErrorType[keyof typeof ErrorType];
interface ErrorMessagePayload {
    type: ErrorType;
    errorMessageCode: string;
    errorTitle?: string;
    actions?: Action[];
}
interface MessageBlock {
    sender: SenderType;
    messages?: Array<MessagePayload | ErrorMessagePayload>;
    timestamp?: Date;
    fromHistory?: boolean;
}
interface ODAConfig {
    uri: string;
    channelId: string;
    userId: string;
    initUserProfile: UserProfileMessage;
    initUserHiddenMessage: string;
    enableLocalConversationHistory: boolean;
}
export default class ViewModel implements Composite.ViewModel<Composite.PropertiesType> {
    busyResolve: (() => void);
    composite: Element;
    userInput: ko.Observable<string>;
    properties: Composite.PropertiesType;
    messages: ko.ObservableArray<MessageBlock>;
    suggestionData: ko.ObservableArray<{
        key: number;
        value: string;
    }>;
    core: WebCore;
    lastMsgTime: number;
    lastStampTime: number;
    lastMsgSender: SenderType;
    typingCueTimer: number;
    typingCueTimeoutTimer: number;
    elemId: string;
    isInitMessageSent: boolean;
    isConnecting: boolean;
    isConnected: ko.Observable<boolean>;
    storageKey: string;
    constructor(context: Composite.ViewModelContext<Composite.PropertiesType>);
    initCore: (config: ODAConfig) => void;
    getLastMessageBlock: () => MessageBlock | undefined;
    updateMessageList: (messagePayload: MessagePayload | ErrorMessagePayload, sender: SenderType) => void;
    showTypingCue: (delay?: number) => void;
    hideTypingCue: () => void;
    getMessages: () => Array<MessageBlock>;
    saveMessages: () => void;
    addMessageBlock: (messageBlock: MessageBlock) => void;
    handleInputChange: (event: CustomEvent) => void;
    handleBack: (event: CustomEvent) => void;
    startRecording: () => void;
    stopRecording: () => void;
    toggleVoiceMode: (event: CustomEvent) => void;
    handleValueEnter: (event: CustomEvent) => void;
    sendMessage: (message: string | UserMessage, isHidden?: boolean) => Promise<unknown>;
    sendAttachment: (event: CustomEvent) => void;
    receiveMessage: (message: Message) => void;
    handleAction: (event: CustomEvent) => void;
    replaceWithTypingCue: () => void;
    connect: (config?: {
        uri: string;
        channelId: string;
        userId: string;
        message: string;
    }) => Promise<void>;
    sendInitMessage: (initMessage?: string | UserMessage) => void;
    setUserInput: (message: string | null) => void;
    clearConversationHistory: () => void;
    disconnect: () => Promise<void>;
    bindingsApplied(context: Composite.ViewModelContext<Composite.PropertiesType>): void;
    propertyChanged(context: Composite.PropertyChangedContext<Composite.PropertiesType>): void;
    disconnected(): void;
}
export {};
