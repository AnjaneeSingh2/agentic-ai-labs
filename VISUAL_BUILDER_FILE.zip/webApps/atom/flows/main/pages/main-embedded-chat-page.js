define(['WebSDK'], function(WebSDK){
 'use strict';
 var eventHelper;
  
 var PageModule = function PageModule(context) {
  eventHelper = context.getEventHelper();
 };
  
 // Initialize bot
 PageModule.prototype.init = function() {
  console.log("Initializing bot...");
  
  const chatSettings = {

        URI: 'https://oda-XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX-XXXXXXXX.data.digitalassistant.oci.oraclecloud.com/', 
        channelId: 'XXXXXXXX-XXXX-XXXX-XXXX-XXXXXXXXXXXX',
        
        embedded: true,
        theme: 'redwood-dark',
        openChatOnLoad: true,
        openLinksInNewWindow: true,
        //position: { bottom: '2px', right: '2px' },
        initUserHiddenMessage: 'Hi',
        initMessageOptions: { sendAt: 'init' },
        targetElement: 'chat-test',
        showConnectionStatus: true,
        colors: {
          //branding: '#FFFFFF',
          //text: '#000000',
          ratingStar: '#FFFFFF',
          ratingStarFill: '#FFFFFF',
          actionsText: '#FFFFFF',
          agentName: '#FFFFFF', 
          footerButtonFill: '#FFFFFF',
          formActionsText: '#FFFFFF',
          formActionsBackground:'#FFFFFF',
          formActionsBackgroundHover: '#FFFFFF',
          formText: '#FFFFFF',
          formLabel: '#FFFFFF',
          formActionsBorder: '#FFFFFF',
          //actionsText: '#FFFFFF',
          footerButtonBackgroundHover: '#FFFFFF',
          footerButtonFillHover: '#FFFFFF',
          formError: '#FFFFFF',
          //formActionsBorder: '#FFFFFF',
          footerBackground: '#FFFFFF',
          globalActionsBorder: '#FFFFFF',
          launchIconBackground: '#FFFFFF'
          //branding: '#FFFFFF'
        },

        //enableTimestamp: true, // Deprecated
        disablePastActions: 'all',
        isDebugMode: true,
        shareMenuItems: [
          {
            type: 'txt',
            label: 'Upload Text',
          }
        ],
        enableBotAudioResponse: true,
        enableClearMessage: true,
        enableLocalConversationHistory: true,
        showTypingIndicator: true,
        enableAttachment: true,
        enableAutocomplete: true,
        enableAutocompleteClientCache: true,
        enableSpeech: true,
        timeStampMode: 'relative',
        //theme: 'redwood-dark',
        local: 'en-us',
        icons: {
            logo: 'https://objectstorage.us-chicago-1.oraclecloud.com/n/idb6enfdcxbl/b/image/o/atom-64.png',
            rating: '<svg height="24" width="24" xmlns="http://www.w3.org/2000/svg"><path d="M15.994 3.006a5.7 5.7 0 00-3.795 1.707L12 4.916l-.199-.202a5.676 5.676 0 00-8.128 0c-2.231 2.275-2.231 5.953 0 8.228L12 21.428l8.326-8.486A5.873 5.873 0 0022 8.828a5.873 5.873 0 00-1.675-4.115A5.693 5.693 0 0016.262 3z"/></svg>',    // A heart icon
            avatarAgent: '<svg xmlns="http://www.w3.org/2000/svg" height="32" width="32"><path fill="white" d="M12 2c5.523 0 10 4.477 10 10a9.982 9.982 0 01-3.804 7.85L18 20a9.952 9.952 0 01-6 2C6.477 22 2 17.523 2 12S6.477 2 12 2zm2 16h-4a2 2 0 00-1.766 1.06c1.123.6 2.405.94 3.766.94s2.643-.34 3.765-.94a1.997 1.997 0 00-1.616-1.055zM12 4a8 8 0 00-5.404 13.9A3.996 3.996 0 019.8 16.004L10 16h4c1.438 0 2.7.76 3.404 1.899A8 8 0 0012 4zm0 2c2.206 0 4 1.794 4 4s-1.794 4-4 4-4-1.794-4-4 1.794-4 4-4zm0 2c-1.103 0-2 .897-2 2s.897 2 2 2 2-.897 2-2-.897-2-2-2z" fill="#100f0e" fill-rule="evenodd"/></svg>',
            avatarUser: '<svg xmlns="http://www.w3.org/2000/svg" height="32" width="32"><path fill="white" d="M12 2c5.523 0 10 4.477 10 10a9.982 9.982 0 01-3.804 7.85L18 20a9.952 9.952 0 01-6 2C6.477 22 2 17.523 2 12S6.477 2 12 2zm2 16h-4a2 2 0 00-1.766 1.06c1.123.6 2.405.94 3.766.94s2.643-.34 3.765-.94a1.997 1.997 0 00-1.616-1.055zM12 4a8 8 0 00-5.404 13.9A3.996 3.996 0 019.8 16.004L10 16h4c1.438 0 2.7.76 3.404 1.899A8 8 0 0012 4zm0 2c2.206 0 4 1.794 4 4s-1.794 4-4 4-4-1.794-4-4 1.794-4 4-4zm0 2c-1.103 0-2 .897-2 2s.897 2 2 2 2-.897 2-2-.897-2-2-2z" fill="#100f0e" fill-rule="evenodd"/></svg>',
            avatarBot: 'https://objectstorage.us-chicago-1.oraclecloud.com/n/idb6enfdcxbl/b/image/o/atom-64.png'
        },

        "i18n": {

          "en": {
            "chatTitle": "ATOM"
          }
        }
  };

 
  setTimeout(() => { 
            window.Bots = new WebSDK(chatSettings); 
            window.Bots.connect().then(() => { 
                console.log("Connection Successful"); 
            }, (reason) => { 
                console.log("Connection failed"); 
                console.log(reason); 
            }); 
        }, 0); 
 };
  
 return PageModule;
});