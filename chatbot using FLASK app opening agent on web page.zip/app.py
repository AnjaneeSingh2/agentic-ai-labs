#!/usr/bin/env python3
"""
app.py
======
Web front end for the OCI Generative AI Agent, built on top of the same
oci.generative_ai_agent_runtime logic as independent_query_oci_agent.py.

Instead of a terminal loop, this exposes:
  - GET  /            -> chat UI (single HTML page)
  - POST /api/chat    -> {"message": "..."} -> {"reply": "...", "citations": [...]}
  - GET  /api/health  -> quick check that the OCI session is alive

Run it on your instance with:
    python3 app.py
then open http://<instance-public-ip>:5000 in a browser.

Configuration is via the same environment variables as the CLI script:
    OCI_CONFIG_PROFILE   (default: DEFAULT)
    AGENT_ENDPOINT_ID    (required)
    OCI_GENAI_AGENT_SERVICE_ENDPOINT (optional)
    PORT                 (default: 5000)
"""

import os
import sys
import threading

import oci
from flask import Flask, jsonify, render_template, request
from oci.generative_ai_agent_runtime import GenerativeAiAgentRuntimeClient
from oci.generative_ai_agent_runtime.models import ChatDetails, CreateSessionDetails

# ---- Configuration --------------------------------------------------------
CONFIG_PROFILE = os.getenv("OCI_CONFIG_PROFILE", "DEFAULT")
AGENT_ENDPOINT_ID = os.getenv("AGENT_ENDPOINT_ID", "")
SERVICE_ENDPOINT = os.getenv("OCI_GENAI_AGENT_SERVICE_ENDPOINT")
PORT = int(os.getenv("PORT", "5000"))
# ---------------------------------------------------------------------------

app = Flask(__name__)

# One shared OCI client + session for the whole app process. This mirrors the
# single-user, single-session behavior of the original CLI script. Guarded by
# a lock since Flask's dev server (and gunicorn with threads) can handle
# concurrent requests.
_state = {"client": None, "session_id": None}
_lock = threading.Lock()


def _build_client() -> GenerativeAiAgentRuntimeClient:
    config = oci.config.from_file(profile_name=CONFIG_PROFILE)
    kwargs = {"retry_strategy": oci.retry.DEFAULT_RETRY_STRATEGY}
    if SERVICE_ENDPOINT:
        kwargs["service_endpoint"] = SERVICE_ENDPOINT
    return GenerativeAiAgentRuntimeClient(config, **kwargs)


def _create_session(client: GenerativeAiAgentRuntimeClient) -> str:
    try:
        session_details = CreateSessionDetails(
            display_name="web-session",
            idle_timeout_in_seconds=3600,
        )
    except TypeError:
        session_details = CreateSessionDetails(display_name="web-session")

    session = client.create_session(
        create_session_details=session_details,
        agent_endpoint_id=AGENT_ENDPOINT_ID,
    )
    return session.data.id


def _ensure_session():
    """Lazily create the OCI client + chat session on first use, or after a
    session has expired / been invalidated."""
    with _lock:
        if _state["client"] is None:
            _state["client"] = _build_client()
        if _state["session_id"] is None:
            _state["session_id"] = _create_session(_state["client"])
    return _state["client"], _state["session_id"]


def _extract_text_and_citations(message_content):
    text = getattr(message_content, "text", None)
    if text is None:
        text = str(message_content)
    citations = getattr(message_content, "citations", None) or []
    formatted_citations = []
    for c in citations:
        source_title = getattr(c, "source_title", None) or getattr(c, "title", None) or "unknown"
        source_location = getattr(c, "source_location", None)
        url = getattr(source_location, "url", None) if source_location else None
        formatted_citations.append({"title": source_title, "url": url})
    return text, formatted_citations


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/health")
def health():
    if not AGENT_ENDPOINT_ID:
        return jsonify({"ok": False, "error": "AGENT_ENDPOINT_ID is not set on the server."}), 500
    return jsonify({"ok": True})


@app.route("/api/chat", methods=["POST"])
def chat():
    if not AGENT_ENDPOINT_ID:
        return jsonify({"error": "AGENT_ENDPOINT_ID is not set on the server."}), 500

    payload = request.get_json(silent=True) or {}
    question = (payload.get("message") or "").strip()
    if not question:
        return jsonify({"error": "Empty message."}), 400

    try:
        client, session_id = _ensure_session()
        response = client.chat(
            agent_endpoint_id=AGENT_ENDPOINT_ID,
            chat_details=ChatDetails(
                user_message=question,
                session_id=session_id,
                should_stream=False,
            ),
        )
        content = response.data.message.content
        text, citations = _extract_text_and_citations(content)
        return jsonify({"reply": text, "citations": citations})

    except oci.exceptions.ServiceError as e:
        # If the session died (e.g. idle timeout), drop it so the next
        # request creates a fresh one instead of failing forever.
        if e.status in (400, 404):
            with _lock:
                _state["session_id"] = None
        return jsonify({"error": f"OCI service error ({e.status} {e.code}): {e.message}"}), 502

    except oci.exceptions.RequestException as e:
        return jsonify({"error": f"Network/request error: {e}"}), 502


if __name__ == "__main__":
    if not AGENT_ENDPOINT_ID:
        sys.exit(
            "Set AGENT_ENDPOINT_ID before running, e.g.\n"
            "  export AGENT_ENDPOINT_ID=ocid1.genaiagentendpoint.oc1...\n"
            "  python3 app.py"
        )
    # host=0.0.0.0 so it's reachable via the instance's public/private IP,
    # not just localhost.
    app.run(host="0.0.0.0", port=PORT, debug=False)
