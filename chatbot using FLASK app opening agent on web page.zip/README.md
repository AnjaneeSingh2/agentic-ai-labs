# Agent Console — web wrapper for your OCI Generative AI Agent

This turns `independent_query_oci_agent.py` into a small web app instead of a
CLI tool. Open a browser at `http://<instance-ip>:5000`, and you get the same
chat you had on the terminal, with replies (and citations) printed in the
page instead of stdout.

## Files
- `app.py` — Flask backend. Same OCI SDK calls as your CLI script
  (`create_session` + `chat`), exposed as `/api/chat`.
- `templates/index.html` — the chat page (plain HTML/CSS/JS, no build step).
- `requirements.txt` — `flask`, `oci`, `gunicorn`.

## 1. Put this on your instance
Copy the whole `oci_agent_web/` folder to your OCI compute instance (`scp`,
`git`, whatever you already use).

## 2. Install dependencies
```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
```

Make sure `~/.oci/config` exists on the instance with a working profile (same
requirement as your original script), and that the instance's principal/user
has policy to `USE generative-ai-agent-runtime-family` in the agent's
compartment.

## 3. Set the agent endpoint
```bash
export AGENT_ENDPOINT_ID="ocid1.genaiagentendpoint.oc1...."
# optional:
export OCI_CONFIG_PROFILE=DEFAULT
export OCI_GENAI_AGENT_SERVICE_ENDPOINT=...
export PORT=5000
```

## 4. Open the port on the instance
Two firewalls need to allow the port (5000, or whatever you set `PORT` to):

**a) OCI Security List / Network Security Group** (in the OCI console, on the
subnet/VNIC your instance uses): add an ingress rule for your port, TCP,
source `0.0.0.0/0` (or your IP range) — same place you'd open 22 or 443.

**b) The instance's own OS firewall**, e.g. on Oracle Linux:
```bash
sudo firewall-cmd --permanent --add-port=5000/tcp
sudo firewall-cmd --reload
```

## 5. Run it

Quick test:
```bash
python3 app.py
```

For anything longer-lived than a terminal session, run it under `gunicorn`
and keep it alive with `nohup` or a systemd unit:
```bash
nohup gunicorn -w 2 -b 0.0.0.0:5000 app:app > agent-web.log 2>&1 &
```

(`-w 2` = 2 worker processes; since the OCI chat session is currently held
in-process per worker, keep this small unless you extend `app.py` to share
session state, e.g. in a file or Redis, across workers.)

## 6. Open it
In your browser: `http://<instance-public-ip>:5000`

You should see the console UI, a "ready" status once `/api/health` confirms
`AGENT_ENDPOINT_ID` is set, and can start typing questions — replies and any
knowledge-base citations show inline.

## Notes / things you may want to change
- **HTTPS**: this serves plain HTTP. For anything beyond quick testing, put
  it behind nginx/Caddy with a TLS cert, or an OCI Load Balancer.
- **Auth**: there's currently no login — anyone who can reach the port can
  use the agent. Fine for a private/test instance; add HTTP basic auth or a
  reverse-proxy auth layer before exposing it more broadly.
- **Session lifetime**: the OCI chat session is created once per app process
  and reused for every message; if it goes idle-timeout or errors out,
  `app.py` drops it and creates a fresh one on the next message.
