#!/usr/bin/env python3
"""
instance_host_app.py
=====================
Web front end for the OCI Generative AI Agent, built on top of the same
oci.generative_ai_agent_runtime logic as independent_query_oci_agent.py.

Exposes:
  - GET  /            -> chat UI (whichever single .html file is in templates/)
  - POST /api/chat    -> {"message": "..."} -> {"reply": "...", "citations": [...]}
  - GET  /api/health  -> quick check that the agent endpoint is configured

The chat UI's filename is auto-detected from templates/ at startup -- keep
exactly one .html file there and name it whatever you like; this file
never needs editing when you rename it.

Run it on your instance with:
    python3 instance_host_app.py
then open http://<instance-public-ip>:5000 in a browser.

NOTE: AGENT_ENDPOINT_ID is hardcoded below (per request) instead of read from
an environment variable, so there's no risk of forgetting to `export` it
before starting the app. If you ever need to point this at a different
agent, edit AGENT_ENDPOINT_ID directly in this file.
"""

import sys
import threading
from pathlib import Path

import oci
from flask import Flask, jsonify, render_template, request
from oci.generative_ai_agent_runtime import GenerativeAiAgentRuntimeClient
from oci.generative_ai_agent_runtime.models import ChatDetails, CreateSessionDetails

# ---- Configuration --------------------------------------------------------
# Hardcoded on purpose -- see module docstring above.
AGENT_ENDPOINT_ID = "ocid1.genaiagentendpoint.oc1.eu-frankfurt-1.amaaaaaabjoaylqadtqievgf46kgqrcacvllcgj2ehnp7jeip5xwlzczu3yq"

# Leave these as-is unless you have a specific reason to change them.
CONFIG_PROFILE = "DEFAULT"          # profile name in ~/.oci/config on this VM
SERVICE_ENDPOINT = None             # set to a string only if you need to override the regional endpoint
PORT = 5000
# ---------------------------------------------------------------------------

app = Flask(__name__)


def _find_template_name() -> str:
    """Auto-detect the chat UI's HTML filename inside templates/, instead of
    hardcoding it -- so renaming that file later never breaks this app.
    Requires exactly one .html file in templates/ (fails loudly, not
    silently, if that's ever not true)."""
    template_dir = Path(app.root_path) / "templates"
    html_files = sorted(template_dir.glob("*.html"))
    if not html_files:
        sys.exit(f"No .html file found in {template_dir}. Put your chat UI page there.")
    if len(html_files) > 1:
        names = ", ".join(f.name for f in html_files)
        sys.exit(f"Multiple .html files found in {template_dir} ({names}). Keep exactly one.")
    return html_files[0].name


TEMPLATE_NAME = _find_template_name()

# One shared OCI client + session for the whole app process (single-user,
# single-session behavior). Guarded by a lock since gunicorn with multiple
# workers/threads can handle concurrent requests.
_state = {"client": None, "session_id": None}
_lock = threading.Lock()


def _build_client() -> GenerativeAiAgentRuntimeClient:
    config = oci.config.from_file(profile_name=CONFIG_PROFILE)
    kwargs = {"retry_strategy": oci.retry.DEFAULT_RETRY_STRATEGY}
    if SERVICE_ENDPOINT:
        kwargs["service_endpoint"] = SERVICE_ENDPOINT
    return GenerativeAiAgentRuntimeClient(config, **kwargs)


def _create_session(client: GenerativeAiAgentRuntimeClient) -> str:
    try:
        session_details = CreateSessionDetails(
            display_name="web-session",
            idle_timeout_in_seconds=3600,
        )
    except TypeError:
        # Installed oci SDK version doesn't support idle_timeout_in_seconds
        # on this call -- fall back to the minimal signature.
        session_details = CreateSessionDetails(display_name="web-session")

    session = client.create_session(
        create_session_details=session_details,
        agent_endpoint_id=AGENT_ENDPOINT_ID,
    )
    return session.data.id


def _ensure_session():
    """Lazily create the OCI client + chat session on first use, or after a
    session has expired / been invalidated."""
    with _lock:
        if _state["client"] is None:
            _state["client"] = _build_client()
        if _state["session_id"] is None:
            _state["session_id"] = _create_session(_state["client"])
    return _state["client"], _state["session_id"]


def _extract_text_and_citations(message_content):
    text = getattr(message_content, "text", None)
    if text is None:
        text = str(message_content)
    citations = getattr(message_content, "citations", None) or []
    formatted_citations = []
    for c in citations:
        source_title = getattr(c, "source_title", None) or getattr(c, "title", None) or "unknown"
        source_location = getattr(c, "source_location", None)
        url = getattr(source_location, "url", None) if source_location else None
        formatted_citations.append({"title": source_title, "url": url})
    return text, formatted_citations


@app.route("/")
def index():
    return render_template(TEMPLATE_NAME)


@app.route("/api/health")
def health():
    return jsonify({"ok": True})


@app.route("/api/chat", methods=["POST"])
def chat():
    payload = request.get_json(silent=True) or {}
    question = (payload.get("message") or "").strip()
    if not question:
        return jsonify({"error": "Empty message."}), 400

    try:
        client, session_id = _ensure_session()
        response = client.chat(
            agent_endpoint_id=AGENT_ENDPOINT_ID,
            chat_details=ChatDetails(
                user_message=question,
                session_id=session_id,
                should_stream=False,
            ),
        )
        content = response.data.message.content
        text, citations = _extract_text_and_citations(content)
        return jsonify({"reply": text, "citations": citations})

    except oci.exceptions.ServiceError as e:
        # If the session died (e.g. idle timeout), drop it so the next
        # request creates a fresh one instead of failing forever.
        if e.status in (400, 404):
            with _lock:
                _state["session_id"] = None
        return jsonify({"error": f"OCI service error ({e.status} {e.code}): {e.message}"}), 502

    except oci.exceptions.RequestException as e:
        return jsonify({"error": f"Network/request error: {e}"}), 502


if __name__ == "__main__":
    # host=0.0.0.0 so it's reachable via the instance's public/private IP,
    # not just localhost.
    app.run(host="0.0.0.0", port=PORT, debug=False)
