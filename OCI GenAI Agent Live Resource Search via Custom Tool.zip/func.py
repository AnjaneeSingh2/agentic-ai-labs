import io
import ipaddress
import json
import logging
import re
from collections import Counter
from itertools import combinations

import oci
from fdk import response

DEFAULT_QUERY = "query all resources"
DEFAULT_MAX_RESULTS = 50      # small default so agent responses stay compact
HARD_MAX_RESULTS = 1000       # upper bound for list output
SUMMARY_MAX_SCAN = 10000      # upper bound on resources scanned for summary output
PAGE_LIMIT = 1000             # max page size supported by the Search API
TOP_COMPARTMENTS = 10         # compartments listed in the summary


def get_signer():
    """Authenticate with Resource Principals (works inside OCI Functions)."""
    return oci.auth.signers.get_resource_principals_signer()


def get_search_client(signer):
    return oci.resource_search.ResourceSearchClient(config={}, signer=signer)


KNOWN_TYPES = {
    "instance", "bootvolume", "volume", "bucket", "vcn", "subnet", "securitylist",
    "networksecuritygroup", "loadbalancer", "autonomousdatabase", "dbsystem",
    "functionsapplication", "functionsfunction", "compartment", "user", "group", "policy",
    "routetable", "internetgateway", "natgateway", "servicegateway", "drg", "all",
}
TYPE_ALIASES = {
    "vcns": "vcn", "subnets": "subnet", "instances": "instance", "buckets": "bucket",
    "volumes": "volume", "bootvolumes": "bootvolume", "policies": "policy",
    "compartments": "compartment", "users": "user", "groups": "group",
    "loadbalancers": "loadbalancer", "securitylists": "securitylist",
    "network": "vcn", "networks": "vcn", "compute": "instance",
}
SYNTAX_HINT = (
    "Structured query syntax: query <type> resources [where <attribute> = 'value'] "
    "[sorted by <attribute> asc|desc]. Example: query vcn resources where "
    "displayName = 'Hub_Network'. Types: " + ", ".join(sorted(KNOWN_TYPES)) + "."
)
_QUERY_RE = re.compile(
    r"^\s*query\s+(?P<types>.+?)(?P<rest>\s+(resources|return|where|sorted\s+by)\b.*)?$",
    re.IGNORECASE | re.DOTALL,
)


def normalize_query(query):
    """Fix common mistakes such as 'query vcns where ...' -> 'query vcn resources where ...'."""
    m = _QUERY_RE.match(query or "")
    if not m:
        raise ValueError("Query must start with 'query'. " + SYNTAX_HINT)
    types = [t.strip().lower() for t in m.group("types").split(",") if t.strip()]
    types = [TYPE_ALIASES.get(t, t) for t in types]
    rest = (m.group("rest") or "").strip()
    if not rest.lower().startswith("resources"):
        rest = ("resources " + rest).strip()
    return f"query {', '.join(types)} {rest}"


def build_search_details(body):
    """
    Supports two search modes:
      - structured (default): {"query": "query instance resources where lifecycleState = 'RUNNING'"}
      - free text:            {"text": "my-bucket", "type": "freetext"}
    """
    search_type = str(body.get("type", "structured")).lower()

    if search_type == "freetext":
        text = body.get("text")
        if not text:
            raise ValueError("'text' is required when type is 'freetext'")
        return oci.resource_search.models.FreeTextSearchDetails(
            text=text,
            matching_context_type="NONE",
        )
    if search_type != "structured":
        raise ValueError("'type' must be 'structured' or 'freetext'")

    query = normalize_query(body.get("query") or DEFAULT_QUERY)
    if parse_bool(body.get("include_details", False)) and "allAdditionalFields" not in query:
        # Search only accepts "return allAdditionalFields" before "where" / "sorted by"
        lowered = query.lower()
        cut = min([i for i in (lowered.find(" where "), lowered.find(" sorted by ")) if i != -1],
                  default=len(query))
        query = query[:cut] + " return allAdditionalFields" + query[cut:]
    return oci.resource_search.models.StructuredSearchDetails(
        query=query,
        matching_context_type="NONE",
    )


def iter_resources(client, details, max_items):
    """Yield resource summaries, following pagination until max_items is reached.

    Returns (via StopIteration value) whether more results were left unread.
    """
    fetched, page = 0, None
    while fetched < max_items:
        resp = client.search_resources(
            search_details=details,
            limit=min(PAGE_LIMIT, max_items - fetched),
            page=page,
        )
        for item in resp.data.items:
            fetched += 1
            yield item
        page = resp.next_page
        if not page:
            return False
    return bool(page)


def to_dict(item, include_tags, include_details=False):
    result = {
        "resource_type": item.resource_type,
        "display_name": item.display_name,
        "identifier": item.identifier,
        "compartment_id": item.compartment_id,
        "lifecycle_state": item.lifecycle_state,
        "availability_domain": item.availability_domain,
        "time_created": item.time_created.isoformat() if item.time_created else None,
    }
    if include_tags:
        result["freeform_tags"] = item.freeform_tags
        result["defined_tags"] = item.defined_tags
    if include_details and getattr(item, "additional_details", None):
        result["details"] = item.additional_details
    return result


def add_network_details(items, signer):
    """Always add CIDR blocks to VCN and subnet items, so the agent never has to ask for them."""
    if signer is None or not any(i["resource_type"] in ("Vcn", "Subnet") for i in items):
        return
    network = oci.core.VirtualNetworkClient(config={}, signer=signer)
    vcn_names = {}
    for item in items:
        try:
            if item["resource_type"] == "Vcn":
                vcn = network.get_vcn(item["identifier"]).data
                item["cidr_blocks"] = vcn.cidr_blocks or [vcn.cidr_block]
            elif item["resource_type"] == "Subnet":
                sn = network.get_subnet(item["identifier"]).data
                item["cidr_block"] = sn.cidr_block
                if sn.vcn_id not in vcn_names:
                    vcn_names[sn.vcn_id] = network.get_vcn(sn.vcn_id).data.display_name
                item["vcn_name"] = vcn_names[sn.vcn_id]
        except oci.exceptions.ServiceError as e:
            item["cidr_error"] = e.code


def run_list(client, details, max_results, include_tags, include_details=False, signer=None):
    gen = iter_resources(client, details, max_results)
    items = []
    truncated = False
    while True:
        try:
            items.append(to_dict(next(gen), include_tags, include_details))
        except StopIteration as stop:
            truncated = bool(stop.value)
            break
    add_network_details(items, signer)
    return {"output": "list", "count": len(items), "truncated": truncated, "items": items}


def run_summary(client, details):
    by_type, by_state, by_compartment = Counter(), Counter(), Counter()
    by_type_state = Counter()
    gen = iter_resources(client, details, SUMMARY_MAX_SCAN)
    truncated = False
    while True:
        try:
            item = next(gen)
        except StopIteration as stop:
            truncated = bool(stop.value)
            break
        state = item.lifecycle_state or "UNKNOWN"
        by_type[item.resource_type] += 1
        by_state[state] += 1
        by_compartment[item.compartment_id] += 1
        by_type_state[f"{item.resource_type}:{state}"] += 1

    return {
        "output": "summary",
        "total": sum(by_type.values()),
        "truncated": truncated,
        "by_resource_type": dict(by_type.most_common()),
        "by_lifecycle_state": dict(by_state.most_common()),
        "by_resource_type_and_state": dict(by_type_state.most_common()),
        "top_compartments": dict(by_compartment.most_common(TOP_COMPARTMENTS)),
    }


def run_cidr_check(signer, search_client):
    """Find duplicate / overlapping CIDRs between VCNs, and between subnets of different VCNs."""
    network = oci.core.VirtualNetworkClient(config={}, signer=signer)
    vcn_query = oci.resource_search.models.StructuredSearchDetails(
        query="query vcn resources where lifecycleState = 'AVAILABLE'",
        matching_context_type="NONE",
    )
    ranges, skipped = [], []
    for item in iter_resources(search_client, vcn_query, SUMMARY_MAX_SCAN):
        try:
            vcn = network.get_vcn(item.identifier).data
            subnets = oci.pagination.list_call_get_all_results(
                network.list_subnets, compartment_id=vcn.compartment_id, vcn_id=vcn.id
            ).data
        except oci.exceptions.ServiceError as e:
            skipped.append({"vcn": item.display_name, "error": e.code})
            continue
        for cidr in vcn.cidr_blocks or [vcn.cidr_block]:
            ranges.append({"kind": "VCN", "name": vcn.display_name, "cidr": cidr,
                           "vcn": vcn.display_name, "vcn_id": vcn.id,
                           "compartment_id": vcn.compartment_id})
        for sn in subnets:
            ranges.append({"kind": "Subnet", "name": sn.display_name, "cidr": sn.cidr_block,
                           "vcn": vcn.display_name, "vcn_id": vcn.id,
                           "compartment_id": sn.compartment_id})

    conflicts = []
    for kind in ("VCN", "Subnet"):
        items = [r for r in ranges if r["kind"] == kind]
        for a, b in combinations(items, 2):
            if a["vcn_id"] == b["vcn_id"]:
                continue
            na, nb = ipaddress.ip_network(a["cidr"]), ipaddress.ip_network(b["cidr"])
            if na == nb or na.overlaps(nb):
                conflicts.append({
                    "status": "DUPLICATE" if na == nb else "OVERLAP",
                    "kind": kind,
                    "first": {k: a[k] for k in ("name", "cidr", "vcn", "compartment_id")},
                    "second": {k: b[k] for k in ("name", "cidr", "vcn", "compartment_id")},
                })

    return {
        "output": "cidr_check",
        "region": getattr(signer, "region", None),
        "vcn_cidrs_checked": sum(r["kind"] == "VCN" for r in ranges),
        "subnet_cidrs_checked": sum(r["kind"] == "Subnet" for r in ranges),
        "conflict_count": len(conflicts),
        "conflicts": conflicts[:200],
        "conflicts_truncated": len(conflicts) > 200,
        "all_ranges": [{k: r[k] for k in ("kind", "name", "cidr", "vcn")} for r in ranges][:500],
        "skipped": skipped,
    }


def parse_bool(value):
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "1", "yes")


def handler(ctx, data: io.BytesIO = None):
    logger = logging.getLogger()
    try:
        raw = data.getvalue() if data else b""
        body = json.loads(raw) if raw else {}
        if not isinstance(body, dict):
            raise ValueError("Request body must be a JSON object")

        output = str(body.get("output", "list")).lower()
        if output not in ("list", "summary", "cidr_check"):
            raise ValueError("'output' must be 'list', 'summary' or 'cidr_check'")

        max_results = int(body.get("max_results", DEFAULT_MAX_RESULTS))
        max_results = max(1, min(max_results, HARD_MAX_RESULTS))
        include_tags = parse_bool(body.get("include_tags", False))
        include_details = parse_bool(body.get("include_details", False))

        signer = get_signer()
        client = get_search_client(signer)

        if output == "cidr_check":
            payload = run_cidr_check(signer, client)
        elif output == "summary":
            payload = run_summary(client, build_search_details(body))
        else:
            details = build_search_details(body)
            payload = run_list(client, details, max_results, include_tags, include_details, signer)
        status = 200
    except (ValueError, json.JSONDecodeError) as e:
        payload, status = {"error": str(e)}, 400
    except oci.exceptions.ServiceError as e:
        logger.error("OCI service error: %s", e)
        payload, status = {"error": e.message, "code": e.code}, e.status
        if e.status == 400:
            payload["hint"] = SYNTAX_HINT
    except Exception as e:
        logger.exception("Unexpected error")
        payload, status = {"error": str(e)}, 500

    return response.Response(
        ctx,
        response_data=json.dumps(payload, default=str),
        headers={"Content-Type": "application/json"},
        status_code=status,
    )
